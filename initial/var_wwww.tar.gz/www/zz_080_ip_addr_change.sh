#!/bin/bash  
#################################################################################
#                                                                               #
# Script Name: zz_080_ip_addr_change.sh                                         #
#                                                                               #
# Description: xxxxxxxxxxxxxxxxxxxx script                                      #
#                                                                               #
# Modified:                                                                     #
#                                                                               #
#  2015.10.19 SAL_SUM:xxxxx                                                     #
#             created by root                                                   #
#                                                                               #
# Licensed Materials - Property of SKB CloudPC                                       #
#                                                                               #
# (C) COPYRIGHT SKB CloudPC Co., Ltd. 2009                                           #
# All Rights Reserved                                                           #
#                                                                               #
#################################################################################

typeset my_ip=$( hostname -i | awk '{print $1}' )
typeset from_ip="10.78.35.35"
typeset to_ip="${1:-${my_ip}}"

function Getyn {
    while echo -e "\n${*}\c"
     do read yn
             case "$yn" in
                     [Yy]) return 0                        ;;
                     [Nn]) echo -e "\nRequest CANCELED."
                           sleep 1; exit 1                 ;;
                        *) echo -e "\nPlease enter y or n" ;;
             esac
     done
}

function view_from_ip {
  cd /var/www
  #grep -r "${from_ip}" /var/www  | grep -v zz_080_ip_addr_change.sh
  echo "grep -r ${from_ip} /var/www" 
  echo "---------------------------"
  grep -r "${from_ip}" /var/www  | egrep -v "zz_080_ip_addr_change.sh|main_left.html"
  echo -e "\n\n\n"
}

## main routine ## 

view_from_ip

## ip change confirm ### 
set -v
grep "${from_ip}" /var/www/main_left_v0.html
set +v
echo  "From IP: ${from_ip}"
echo  "To   IP: ${to_ip}"
Getyn "IP Address change .... continue (y/n)?"

## ip change ##
set -vx
cd /var/www
sed -i "s/${from_ip}/${to_ip}/g" /var/www/main_left_v0.html
set +vx


view_from_ip
