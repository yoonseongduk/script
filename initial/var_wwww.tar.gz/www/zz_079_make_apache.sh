#!/bin/bash -vx

cd $(dirname $0)
my_dir=$(pwd)
www_file=${my_dir}/www.tar

#apt-get install apache2

TEXT='/etc/apache2/sites-enabled/000-default'


y=$( grep 'ScriptAlias /rexx/' ${TEXT} | wc -l )
###
### add rexx cgi by auto-script
#         ScriptAlias /rexx/  /var/www/rexx/
#        <Directory "/var/www/rexx">
#                AllowOverride None
#                Options +ExecCGI -MultiViews +SymLinksIfOwnerMatch
#                Order allow,deny
#                Allow from all
#        </Directory>
#
#        ErrorLog ${APACHE_LOG_DIR}/error.log
##
if [[ $y -eq 0 ]] ; then 
   sed -i '/ErrorLog/i ## add rexx cgi by auto-script\n         ScriptAlias /rexx/  /var/www/rexx/\n        <Directory "/var/www/rexx">\n                AllowOverride None\n                Options +ExecCGI -MultiViews +SymLinksIfOwnerMatch\n                Order allow,deny\n                Allow from all\n        </Directory>\n' ${TEXT} 
fi

y=$( grep 'Alias /root/ '      ${TEXT} | wc -l )
##
## add root-dir by auto-script
#    Alias /root/ "/"
#    <Directory "/">
#        Options Indexes MultiViews FollowSymLinks
#        AllowOverride None
#        Order allow,deny
#        Allow from all
#    </Directory>
#
#</VirtualHost>
##
if [[ $y -eq 0 ]] ; then 
   sed -i '/<\/VirtualHost>/i ## add root-dir by auto-script\n    Alias /root/ "/"\n    <Directory "/">\n        Options Indexes MultiViews FollowSymLinks\n        AllowOverride None\n        Order allow,deny\n        Allow from all\n    </Directory>\n' ${TEXT}
fi


if [[ ! -d /var/www/rexx ]] ; then 
   cd /var
   #tar -xvf ${www_file} 
fi

usermod -a -G adm  www-data
usermod -a -G root www-data

service apache2 restart

