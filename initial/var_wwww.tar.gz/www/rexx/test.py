#!/usr/bin/python
# -*- coding: utf-8 -*-

from nvd3 import stackedAreaChart

__version__ = "0.1"

if __name__ == '__main__':

  chart = stackedAreaChart(name='stackedAreaChart', height=400, width=800)

  xdata = [100, 101, 102, 103, 104, 105, 106,]
  ydata = [6, 11, 12, 7, 11, 10, 11]
  ydata2 = [8, 20, 16, 12, 20, 28, 28]

  extra_serie = {"tooltip": {"y_start": "There is ", "y_end": " min"}}
  chart.add_serie(name="Serie 1", y=ydata, x=xdata, extra=extra_serie)
  chart.add_serie(name="Serie 2", y=ydata2, x=xdata, extra=extra_serie)

  chart.buildcontent()
  print chart.htmlcontent
