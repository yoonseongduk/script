#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import getopt
import os
import time
import logging
from datetime import date

__version__ = "0.1"

## Window Path
textFileName = 'D:\\tmp\\'+str(date.today())+'_OSI.txt'
logPath='D:\\tmp\\OIS.log'
instanceListFileName = 'D:\\tmp\\'+str(date.today())+'_OSI_instance.txt'
blockListFileName = 'D:\\tmp\\'+str(date.today())+'_OSI_block.txt'
customerListFileName = 'D:\\tmp\\'+str(date.today())+'_OSI_customer.txt'

## Linux Path
#textFileName = '/isc/logs001/OSI_Monitor_log/'+str(date.today())+'_OSI.txt'
#logPath='/isc/logs001/OSI_Monitor_log/OSI_Script.log'
#instanceListFileName = '/isc/logs001/OSI_Monitor_log/'+str(date.today())+'_OSI_instance.txt'
#blockListFileName = '/isc/logs001/OSI_Monitor_log/'+str(date.today())+'_OSI_block.txt'
#customerListFileName = '/isc/logs001/OSI_Monitor_log/'+str(date.today())+'_OSI_customer.txt'

args = sys.argv[1:]
shortopt='i:f:hd'
longopts=['help']
interval=300
debug=0
faultID=0

#My_SQL Info
dbHost='10.78.60.14'
dbUser='nova'
dbPasswd='nova'
dbName='nova'

#MS_SQL Info
MS_dbHost='165.244.26.14'
MS_dbUser='micpcloud'
MS_dbPasswd='#cloud01'
MS_dbName='MICP_DB2'


def help(status=0):
        print "operatingSurppotInfo.py [-n hypervisor_hostname] [-d] [-h]"
        print "-n               hypervisor_hostname"
        print "-h               help"
        print "-d               enable debugging mode"
        sys.exit(status)

def setLogConfig(debug):

        msgFormat='%(asctime)s %(levelname)s %(message)s'
        timeFormat='%Y-%m-%d %H:%M:%S'
        if debug == 1:
                logLevel=logging.DEBUG
        else:
                logLevel=logging.INFO

        logging.basicConfig(filename=logPath, level=logLevel, format=msgFormat, datefmt=timeFormat)







if __name__ == '__main__':
        result = os.system("/var/www/rexx/PaSta_BIZ_board.rexx")
        logging.info(result)
        logging.info('Stop')

