#!/bin/bash

function html_head {
cat <<- EOF
Content-type: text/html

<html>
<head>
 <title>WEB server log clear</title>
</head> 

EOF
}

function html_body {
  echo "<body>"
  echo "<h1>Apache log clear: before status</h1>"
  echo "<pre> "
  echo "---------------"
  ls -al /var/log/apache2/access.*
  echo "---------------"
  ls -al /var/log/apache2/error.*
  echo "---------------"
  
  if [[ -f /var/log/apache2/access.log ]] ; then 
     /usr/local/bin/ssh1 localhost "sudo cat /var/log/apache2/access.log  >> /var/log/apache2/access.log.1"
     /usr/local/bin/ssh1 localhost "sudo cp  /dev/null                       /var/log/apache2/access.log"
  fi
  if [[ -f /var/log/apache2/error.log  ]] ; then 
     /usr/local/bin/ssh1 localhost "sudo cat /var/log/apache2/error.log   >> /var/log/apache2/error.log.1"
     /usr/local/bin/ssh1 localhost "sudo cp  /dev/null                       /var/log/apache2/error.log"
  fi

  echo "<h1>Apache log clear: after  status</h1>"
  echo "<pre> "
  echo "---------------"
  ls -al /var/log/apache2/access.*
  echo "---------------"
  ls -al /var/log/apache2/error.*
  echo "---------------"

  echo "</body>"
}

function html_tail {
cat <<-EOF
</html>
EOF
}
  ## main ##
  html_head
  html_body
  html_tail


