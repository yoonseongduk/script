#!/bin/bash -vx 

##     curl -X POST -d '{"user": {"password": "abc123", "tenantId": "f3e73b04ea014f28808891fccbb88074", "enabled": "true", "name": "swift", "email": "swift@localhost"}}' -H "Content-type: application/json" -H "X-Auth-Token: 999888777666" http://192.168.137.102:35357/v2.0/users

   ## authenticate ##  
   ## curl -v -V 2.0  -H "X-Auth-Key: openstack" -H "X-Auth-user: admin" http://192.168.137.102:8080/v2.0/
 
   curl -d '{"auth":{"tenantName": "ubuntu", "passwordCredentials":{"username": "ubuntu", "password": "openstack"}}}' -H "Content-type: application/json" http://192.168.137.102:5000/v2.0/tokens | python -mjson.tool
