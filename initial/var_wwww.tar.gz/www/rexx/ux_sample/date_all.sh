#!/bin/sh

ssh libcodbp1 date
ssh libcodbp2 date
ssh libcoapp1 date
ssh libcoapp2 date
ssh libcoapt1 date
ssh libcoapt2 date
ssh libcodbt1 date 
ssh libmasvp1 date
ssh libmasvp2 date
ssh libcosvd1 date

