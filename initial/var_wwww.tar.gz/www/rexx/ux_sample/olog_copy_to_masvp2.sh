#!/bin/ksh

TEMPD = DATE('S',(DATE('B') - 1 ),B)

inddx = "/sw/oframe/online_log/olog/svcolog.dbload."||TEMPD
outddx = "/ISC/log/LIBCOAPP1.svcolog."||TEMPD
outddy = "/ISC/log/LIBCOAPP2.svcolog."||TEMPD


"scp libcoapp1:"inddx outddx

"scp libcoapp2:"inddx outddy

exit

