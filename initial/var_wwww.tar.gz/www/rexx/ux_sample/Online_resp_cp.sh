#!/bin/ksh

TODAY=`date +%Y%m%d`
scp libcodbp2:/sw/swwork/Online_resp.txt /sw/tivoli/webdocs/apache/htdocs/LIG/report/day_report/data/$TODAY.online_resp
scp libcodbp2:/sw/swwork/Online_resp_detail.txt /sw/tivoli/webdocs/apache/htdocs/LIG/report/day_report/data/$TODAY.onlin_detail
