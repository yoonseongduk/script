######################### get_stanza_data ##############################
##
## Name:  get_stanza_data
##
## Function:  The get_stanza_data function is responsible for obtaining
##            stanza information from the systems image.data file.  Using
##            the specified parameters, this function will determine
##            the appropriate record value.
##
## Parameters:  stanza, field name, field value, record
##
## Returns:  0 - for completion
##
## Calling Routine:  Several alt_disk_install functions
##
########################################################################

get_stanza_data()
{

	STANZA=$1    ## Stanza Name
	FIELD="$2"   ## Field Name=
	VAL=$3       ## Unique Field Name Value (may be null)
	RECORD=$4    ## Field Name for stanza line you seek the data from.

	if [ "$VAL" = "" ]; then
		VAL1=""
	else
		VAL1=$VAL"$"
	fi

##########################################################
## Ensure that the image.data file contains blank line
## delineations between stanzas and then query for the
## specified parameters
##########################################################

	sed '/:$/i\
' /image.data | grep -p "^"$STANZA: | \
		grep -p "${FIELD}[ 	]*=[ 	]*${VAL1}" | \
		LANG=C egrep "[^A-z_,.0-9\-]$RECORD="| \
		awk -F"=" '{print $2}' | \
		sed 's/^[ 	+]//g' | sed 's/[ 	+]$//g'

	return 0

} # end of get_stanza_data()
