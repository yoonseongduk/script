#!/usr/bin/ksh

 tso workload_cpu.rexx 200712
 tso workload_cpu.rexx 200711
 tso workload_cpu.rexx 200710
 tso workload_cpu.rexx 200709
 tso workload_cpu.rexx 200708
 tso workload_cpu.rexx 200707
 tso workload_cpu.rexx 200706
 tso workload_cpu.rexx 200705
 tso workload_cpu.rexx 200704
 tso workload_cpu.rexx 200703
 tso workload_cpu.rexx 200702
 tso workload_cpu.rexx 200701
 tso workload_cpu.rexx 200612
 tso workload_cpu.rexx 200611
 tso workload_cpu.rexx 200610
 tso workload_cpu.rexx 200609
 tso workload_cpu.rexx 200608
 tso workload_cpu.rexx 200607
