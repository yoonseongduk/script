#!/bin/ksh
SCRIPT_HOME='/sw/BizMaster4/Agent/script'
HOSTNAME=`hostname`
export SCRIPT_HOME
ksh $SCRIPT_HOME'/'$HOSTNAME'/'$*
