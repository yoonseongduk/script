#!/bin/ksh
TOHOST=$1

FROM=/sw/BizMaster4/Server/projobs-master/script/$TOHOST 
TO=/sw/BizMaster4/Agent/script/$TOHOST
  echo $TOHOST 
  scp $FROM/* $TOHOST:$TO/ 
exit

