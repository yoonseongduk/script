for HOST in `cat /ISC/shell/host.list`
do
echo " ### $HOST PM Check !! ### "
ssh $HOST /ISC/PM/pmchk_html.sh
done
