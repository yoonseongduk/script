#!/bin/ksh

HOST2_LIST=/ISC/shell/hosts2.list

BASEDIR1=/ISC/shell
BASEDIR2=/usr/local/bin 
BASEDIR3=/etc/rc.d/rc2.d 

MEM2=iplinfo
MEM3=S10iplinfo 
MEM4=K10iplinfo
MEM5=S15iperf
MEM6=K15iperf


cat $HOST2_LIST | while read host
do
  echo $host
   scp  $BASEDIR2/$MEM2     $host:$BASEDIR2/$MEM2       
   scp  $BASEDIR3/$MEM3     $host:$BASEDIR3/$MEM3       
   scp  $BASEDIR3/$MEM4     $host:$BASEDIR3/$MEM4       
   scp  $BASEDIR1/$MEM5     $host:$BASEDIR3/$MEM5       
   scp  $BASEDIR1/$MEM6     $host:$BASEDIR3/$MEM6       
done

exit 
