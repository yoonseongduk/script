#!/usr/bin/ksh
#
# aix 5.2 aixadmjm_os_vgname_audit.sh 1.0
#
# Licensed Materials - Property of SKB CloudPC
#
# (C) COPYRIGHT SKB CloudPC Co., Ltd. 2007
# All Rights Reserved
#
# Script Name : aixadmjm_os_vgname_audit.sh
# Script ���� : vgname   ǥ�� ���� (for SAL v1.0)
#
# Modified : (�ֱ� ��������� ����)
# 2007.09.21 ������ Initial Build v1.0
#
# Created :
# 2007.09.21 ������ Initial Build v1.0
#---0----1----1----2----2----3----3----4----4----5----5----6----6----7----7----8----8----9----9----0
#---5----0----5----0----5----0----5----0----5----0----5----0----5----0----5----0----5----0----5----0
. ./_grobal.sh

hdisk_summary()
{
   lscfg -lhdisk\* | awk '{print $3" "$4" "$5" "$6" "$7" "$8" "$9" "$10" "}' | sort | nodup_count | while read rec
   do 
     echo $rec
   done
}

cpu_model_serial()
{
  i=0
  lsconf | head -2 | while read rec
  do
    (( i = i + 1 ))
    x[$i]=$rec
  done 
  cpu_type=$( echo ${x[1]} | awk -F: '{print $2}' )
  cpu_seri=$( echo ${x[2]} | awk -F: '{print $2}' )
  print "CPU model and serial : $cpu_type $cpu_seri"
}

emc_disk()
{
  if [ -x "/usr/symcli/bin/symcfg" ] ; then 
     /usr/symcli/bin/symcfg list
  fi
}

vg_list()
{
 i=0      
 lsvg | while read vg 
 do
    print $vg
 done
}

# -----------------
# main routine ----
# -----------------
   print "============================================================================="
   print "hdisk summary : lscfg -l hdisk\*                                             "
   print "=---------------------------------------------------------------------------="
   hdisk_summary
   cpu_model_serial 2> /dev/null
   emc_disk
   print "============================================================================="
   vg_list
   print "============================================================================="

return $?
 
