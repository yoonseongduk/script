#!/usr/bin/ksh
#
# aix 5.2 aixadmjm_os_nmontool_audit.sh 1.0
#
# Licensed Materials - Property of SKB CloudPC
#
# (C) COPYRIGHT SKB CloudPC Co., Ltd. 2007
# All Rights Reserved
#
# Script Name : aixadmjm_os_nmontool_audit.sh
# Script ���� : nmontool    ǥ�� ���� (for SAL v1.0)
#
# Modified : (�ֱ� ��������� ����)
# 2007.09.27 ������ Initial Build v1.0
#
# Created :
# 2007.09.27 ������ Initial Build v1.0
#---0----1----1----2----2----3----3----4----4----5----5----6----6----7----7----8----8----9----9----0
#---5----0----5----0----5----0----5----0----5----0----5----0----5----0----5----0----5----0----5----0

 nmon_location_check()
 {
    print " nmon location check : /usr/local/bin "
    ls -al /usr/local/bin/nmon* 
    print  "#----------------------------------------------------------------------------"
    return $?
 }

 nmon_batch_check()
 {
    print " nmon batch    check : crontab -l |grep nmon"
    crontab -l | grep nmon      
    print  "#----------------------------------------------------------------------------"
    return $?
 }


 print  "#============================================================================"
 print  " OS Terminal ��� ǥ�� Monitoring Tool (NMON) "
 print  "#----------------------------------------------------------------------------"

 nmon_location_check
 nmon_batch_check

 return $?


