#!/bin/ksh

su - xadmyjh

more /home/xadmyjh/which.sh

exit

