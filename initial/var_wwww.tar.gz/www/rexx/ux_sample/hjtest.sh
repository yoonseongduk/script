for HOST in `cat /ISC/shell/host_hj.list`
do
echo $HOST
ssh $HOST ls -lt /ISC/shell
done
