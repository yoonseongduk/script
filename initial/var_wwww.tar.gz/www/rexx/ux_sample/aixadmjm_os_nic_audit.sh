#!/usr/bin/ksh
#
# aix 5.2 aixadmjm_os_nic_audit.sh 1.0
#
# Licensed Materials - Property of SKB CloudPC
#
# (C) COPYRIGHT SKB CloudPC Co., Ltd. 2007
# All Rights Reserved
#
# Script Name : aixadmjm_os_nic_audit.sh
# Script ���� : nic     ǥ�� ���� (for SAL v1.0)
#
# Modified : (�ֱ� ��������� ����)
# 2007.09.27 ������ Initial Build v1.0
#
# Created :
# 2007.09.27 ������ Initial Build v1.0
#---0----1----1----2----2----3----3----4----4----5----5----6----6----7----7----8----8----9----9----0
#---5----0----5----0----5----0----5----0----5----0----5----0----5----0----5----0----5----0----5----0


  print  "#============================================================================"
  print  "# AIX ǥ�� NIC Port Manager : Etherchannel status report                     "
  print  "#----------------------------------------------------------------------------"
  print  ""


  for number in $( LANG=C lsdev -Cc adapter -s pseudo -t ibm_ech -F name| awk -F "ent" '{print $2}' | sort -n ); do
      channel="ent${number}"
      status=$( lsdev -Cc adapter -s pseudo -t ibm_ech | grep $channel | awk '{ print $2 }' )
      print  "#============================================================================"
      dspmsg -s 4 smit.cat 713 'EtherChannel / Link Aggregation: %s \n' $channel
      dspmsg -s 4 smit.cat 714 'Status: %s  \n' $status
      dspmsg -s 4 smit.cat 715 'Attributes: \n'
      print  "#----------------------------------------------------------------------------"
      lsattr -El $channel -F "attribute value description"
      echo ""
  done

  return $?
