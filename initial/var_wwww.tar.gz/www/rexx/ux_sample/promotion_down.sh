#!/bin/ksh

PID=`ps -ef | grep "PromotionServer" | grep -v grep | awk '{print $2}' `

if [ -n "$PID" ]
then
        echo "kill -9 $PID"
        kill -9 $PID
        exit 0
else
        echo "There is no PromotionServer running."
        exit 255
fi
