
SERVERS="LIBCOAPP1 LIBCODBP1 LIBCOAPP2 LIBCODBP2 LIBCOSVD1 LIBCOAPT1 LIBCOAPT2 LIBCODBT1 LIBMASVP1 LIBMASVP2 LIBMASVP3 LIBMASVD1 LIBDWP1 LIBEXDBP1 LIBBADBP2 LIBBASVT1 LIBEXDBP2 LIBBADBP1 LIBEXSVT1"

DATE=`date '+%y%m%d'`

for server in $SERVERS
do
  echo $server
  scp VRTS_get_online_info.sh $server:/ISC/shell
  ssh $server /ISC/shell/VRTS_get_online_info.sh
  sleep 2
  scp $server:/ISC/shell/${server}_$DATE.log /ISC/shell/VRTS_logs/
done


