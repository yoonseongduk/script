#!/bin/ksh

#
#
# Roh Tae-won 2008.03.24

echo "# FC Firmware version"
lsdev -Cc adapter|grep fcs|awk '{print "lsmcode -cd " $1}'|ksh
read DUMMY

echo "# FC - HA config"
lsdev -Cc adapter | grep fcs
read DUMMY

echo "# One Multipath S/W"
vxdmpadm listctlr all
read DUMMY

echo "# Internal disk mirroring"
lsvg -l rootvg
read DUMMY

echo "# NIC Media speed"
entstat -d ent0 | grep -i media
read DUMMY

#lsdev -Cc adapter

echo "# Box must be different - Primary vs Secondary"
lsattr -El sys0 -a systemid
read DUMMY

echo "# compare following files"
echo "/etc/passwd, /etc/group, /etc/security/passwd"
echo "/etc/hosts /etc/services"
read DUMMY

echo "# auto import"
vxdg list |grep 'enabled,shared' | awk '{print $1}' > /tmp/vxdg.shared.$$.list
cat /tmp/vxdg.shared.$$.list | while read DG
do
  echo $DG
  vxdisk -g $DG list |grep -v DEVICE >> /tmp/vxdisk.share.$$.list
done

SHARE_DG_COUNT=`wc /tmp/vxdg.shared.$$.list | awk '{print $1}'`
# check if there is no shared DG with DiskGroup type in VCS
if [ $SHARE_DG_COUNT -eq 0 ];then
   hares -display -attribute DiskGroup -type DiskGroup |grep -v Value | awk '{print $4}' >> /tmp/vxdisk.share.$$.list
   echo "No CFS diskgroup exists in VCS. noautoimport flag must be exist on each disk." 
else
   echo "CFS diskgroup exists. There are autoimport  flags on. You can ignore this."
fi
cat /tmp/vxdisk.share.$$.list | while read LINE
do
  DISK=`echo $LINE | awk '{print $1}'`
  vxdisk list $DISK |grep flag
done
rm /tmp/vxdisk.share.$$.list
rm /tmp/vxdg.shared.$$.list
read DUMMY

echo "# HA version"
lslpp -Lc VRTSvcs.rte
read DUMMY


echo "# OS level compare"
oslevel -rq 
oslevel -s
read DUMMY

echo "# llt stat"
lltstat
lltstat -nvv
read DUMMY

echo "# lltconfig"
lltconfig -T query
read DUMMY

echo "# gabconfig"
gabconfig -a
gabconfig -l
read DUMMY

echo "# hastatus -sum"
hastatus -summary
read DUMMY

echo "# VCS .stale"
[ -r /etc/VRTSvcs/conf/config/.stale ] && ls -al /etc/VRTSvcs/conf/config/.stale

echo "# VCS engine log"
more /var/VRTSvcs/log/engine_A.log


echo "# vxdisk list"
vxdisk list
read DUMMY

vxdisk -o alldgs list
read DUMMY

vxdisk path
read DUMMY

echo "# vxdg list"
vxdg list
read DUMMY
#vxdg list | grep -v NAME | awk '{print "vxdg list " $1}' | sh -x 
#read DUMMY

echo "# vxprint"
vxprint
read DUMMY
vxprint -ht
read DUMMY

echo "# vxdmpadm"
vxdmpadm listctlr all
read DUMMY
vxdmpadm listenclosure all
read DUMMY
echo "run manually : vxdmpadm getdmpnode enclosure=enclosure_name"
read DUMMY

echo "# vxconfigd daemon"
ps -ef | grep vxconfigd


echo "# vxdctl"
vxdctl mode
vxdctl -c mode
read DUMMY

[ -r /var/adm/messages ] && more /var/adm/messages
df -k 

echo "# ifconfig -a"
ifconfig -a

echo "# More than 2 NIC adapter"
lsdev -Cc adapter | grep ent
read DUMMY

echo "# NIC firmare"
#lsdev -Cc adapter|grep Ether|awk '{print "lsmcode -cd " $1}' | ksh
lsdev -Cc adapter |grep ent | grep -iv virtual | awk '{print "lsmcode -cd " $1}' | ksh
read DUMMY

echo "# Multi port adapter usage"
lsdev -Cc adapter|grep -E "2-Port|4-Port"


echo "# hares display "
sleep 2

hares -list -localclus |  awk '{print $1}' | sort -u > /tmp/hares.$$.list
cat /tmp/hares.$$.list | while read RES
do
  hares -display $RES
  sleep 2
done
rm /tmp/hares.$$.list

