su - oframe "-c /ISC/shell/listts_tsam_undo_view.tbsql sys/oframe@LOCAL "
