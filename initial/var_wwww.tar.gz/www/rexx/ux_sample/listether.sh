#!/bin/ksh 

for number in `LANG=C lsdev -Cc adapter -s pseudo -t ibm_ech -F name|awk -F "ent" '{print $2}' | sort -n`
do
    channel="ent${number}"
    status=`lsdev -Cc adapter -s pseudo -t ibm_ech | grep $channel | awk '{ print $2 }'`
    echo 'EtherChannel / Link Aggregation: ' $channel
    echo 'Status: ' $status
    echo 'Attributes:'
    lsattr -El $channel -F "      attribute value description"
    echo ""
done

