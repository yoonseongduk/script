#!/bin/ksh
#TOHOST=$1

tar -cvf /ISC/smit.tar /ISC/smit

scp /ISC/smit.tar LIBCOAPT1:/ISC

scp /ISC/smit.tar LIBCOAPT2:/ISC

scp /ISC/smit.tar LIBCODBT1:/ISC

scp /ISC/smit.tar LIBCOAPP1:/ISC

scp /ISC/smit.tar LIBCOAPP2:/ISC

scp /ISC/smit.tar LIBCODBP1:/ISC

scp /ISC/smit.tar LIBCODBP2:/ISC
