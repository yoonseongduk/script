#!/bin/sh 
PATH="/usr/bin:/sbin:/opt/VRTS/bin:/opt/VRTSvcs/bin"
OUTDD=/ISC/log/veritas
export PATH
HOSTNAME=`hostname`
DATE=`date +%y%m%d`
TIME=`date +%H%M%S`
OFILE="${OUTDD}/${HOSTNAME}_${DATE}.log"
echo "[HOSTNAME : ${HOSTNAME}]" > $OFILE
echo "/ISC/shell/veritas_info.sh "  >> $OFILE
echo "DATE= ${DATE} TIME= ${TIME}"  >> $OFILE            
######
# Volme Manager
echo "==== Volume Manager =====" >> $OFILE
echo "\n## License " >> $OFILE
echo "#vxlicrep" >> $OFILE
vxlicrep >> $OFILE
#
echo "\n## VM Process " >> $OFILE
echo "#ps -ef |grep -i vx" >> $OFILE
ps -ef |grep -i vx >> $OFILE
#
echo "\n## Disks " >> $OFILE
echo "#vxdisk list" >> $OFILE
vxdisk list >> $OFILE
#
echo "\n## DG info" >> $OFILE
echo "#vxdg list" >> $OFILE
vxdg list >> $OFILE
#
echo "\n## Volume info 1" >> $OFILE
echo "#vxprint -th" >> $OFILE
vxprint -th >> $OFILE
#
echo "\n## Volume info 2" >> $OFILE
echo "#vxprint -v" >> $OFILE
vxprint -v >> $OFILE
#
################
# File System
echo "===== File System =====" >> $OFILE
echo "\n\n\n## Disk Free " >> $OFILE
echo "df -g                 " >> $OFILE
df -g                  >> $OFILE
#
echo "\n## Mount info" >> $OFILE
echo "#/usr/sbin/mount" >> $OFILE
/usr/sbin/mount >>$OFILE
#
#####
# VCS 
echo "===== VCS =====" >> $OFILE
echo "\n\n\n## VCS engine " >> $OFILE
echo "#ps -ef |grep -i vcs" >> $OFILE
ps -ef |grep -i vcs >> $OFILE
#
echo "\n## Heartbeat " >> $OFILE
echo "#lltstat -n" >> $OFILE
lltstat -n >> $OFILE
#
echo "#gabconfig -a" >> $OFILE
gabconfig -a >> $OFILE
#
echo "\n## Cluster status" >> $OFILE
echo "#hastatus -sum" >> $OFILE
hastatus -sum >> $OFILE
#
echo "\n## Cluster messages" >> $OFILE
echo "#tail -100 /var/VRTSvcs/log/engine_A.log" >> $OFILE
tail -100 /var/VRTSvcs/log/engine_A.log >> $OFILE
####
echo "\n[EOF]" >> $OFILE
