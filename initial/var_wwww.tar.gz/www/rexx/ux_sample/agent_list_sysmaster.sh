/sw/openframe/master/bin/smadmin << HERE_DOC
ai -a
quit
HERE_DOC
