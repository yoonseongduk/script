file=tibero_stat.txt
while test 1
do
    echo "-------------------------------------------------------------------------------" >> $file
    date >> $file
    echo >> $file

    tbsql sys/oframe@LOCAL  >> $file <<EOT
select count(*), sum(BYTES)/1024 as "BYTES(K)" from _vt_undostat;
select * from _vt_undostat;

select * from dba_data_files where tablespace_name = 'SVR0_UNDO';
select * from _vt_session;
select * from _vt_tx;
select * from _vt_recent_commit_tx;
select * from _vt_open_cursor;
EOT
    sleep 600
done
