#!/bin/ksh

BKDAY="`/usr/local/bin/Dday -2 | cut -c6,7,9,10``/usr/local/bin/Dday -2 | cut -c1,2,3,4`"

cd /sw/oframe/online_log/slog

gzip -c9 slog.$BKDAY > slog.$BKDAY.gz

ls -al slog.$BKDAY.gz
