#!/bin/ksh

RPTDIR="/sw/tivoli/webdocs/apache/htdocs/LIG/report/day_report/data/"
DATE=`date +"%Y%m%d"`
FILE="root@10.255.110.32:/ISC/CSR/TACF/USER/${DATE}.tacf_lid"

ssh LIBCODBP2 /ISC/CSR/TACF/USER/tacf_userinfo.rx
scp ${FILE} ${RPTDIR}
