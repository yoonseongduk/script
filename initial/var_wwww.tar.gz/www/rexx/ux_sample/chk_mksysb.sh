#!/bin/ksh

DATE=`date '+%y%m%d'`
TARGET_DIR=/ISC/log/mksysb
TARGET_LOG=$TARGET_DIR/mksysb.log.$DATE
DEVICE=`lsdev -Cc tape| grep Available | grep "4mm Tape Drive" | awk '{print $1}'`


if [ ! -d $TARGET_DIR ]
then
        mkdir -p $TARGET_DIR
fi

if [ ! -f $TARGET_LOG ]
then
        touch $TARGET_LOG
fi


if [ "$DEVICE" == "" ]
then
        echo "$(date +%D:%T) Device is not ready"
        echo "$(date +%D:%T) Device is not ready." >> $TARGET_LOG
        echo "-------------------------------------------" >> $TARGET_LOG
        exit 0
else
		echo "$(date +%D:%T) Device is ready."
        echo "$(date +%D:%T) Device is ready." >> $TARGET_LOG
        echo "-------------------------------------------" >> $TARGET_LOG
fi


echo "$(date +%D:%T) tctl -f /dev/$DEVICE rewind"
echo "$(date +%D:%T) tctl -f /dev/$DEVICE rewind"  >> $TARGET_LOG
echo "-------------------------------------------" >> $TARGET_LOG
tctl -f /dev/$DEVICE rewind 1>> TARGET_LOG 2>> TARGET_LOG
RC=$?

if [ $RC -eq 0 ]
then
        echo "$(date +%D:%T) Tape $DEVICE is founded."
        echo "$(date +%D:%T) Tape $DEVICE is founded."  >> $TARGET_LOG
        echo "-------------------------------------------" >> $TARGET_LOG
else
        echo "$(date +%D:%T) Tape $DEVICE is not founded. Insert tape to tape device."
        echo "$(date +%D:%T) Tape $DEVICE is not founded. Insert tape to tape device." >> $TARGET_LOG
        echo "-------------------------------------------" >> $TARGET_LOG
fi

