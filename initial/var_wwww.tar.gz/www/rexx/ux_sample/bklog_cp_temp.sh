#!/bin/ksh

BKDAY="`/usr/local/bin/Dday -2 | cut -c6,7,9,10``/usr/local/bin/Dday -2 | cut -c1,2,3,4`"
HOST=`hostname`

case $HOST in
	
    LIBCODBP2)
  
    cp /sw/oframe/online_log/slog/slog.$BKDAY.gz /sw/tmax_log/$BKDAY/$HOST.slog.$BKDAY.gz
    if [ $? -eq 0 ]; then
     rm /sw/oframe/online_log/slog/slog.$BKDAY.gz
    fi

    cp /sw/oframe/online_log/ulog/ulog.$BKDAY.tar.gz /sw/tmax_log/$BKDAY/$HOST.ulog.$BKDAY.tar.gz
    if [ $? -eq 0 ]; then
     rm /sw/oframe/online_log/ulog/ulog.$BKDAY.tar.gz
    fi
    ;;
    
    LIBCOAPP1|LIBCOAPP2|LIBCOSVD1|LIBCOAPT1|LIBCOAPT2)
    
    su - xadmjhm -c "scp /sw/oframe/online_log/slog/slog.$BKDAY.gz libcodbp2:/sw/tmax_log/$BKDAY/$HOST.slog.$BKDAY.gz"
    if [ $? -eq 0 ]; then
     rm /sw/oframe/online_log/slog/slog.$BKDAY.gz
    fi

    su - xadmjhm -c "scp /sw/oframe/online_log/ulog/ulog.$BKDAY.tar.gz libcodbp2:/sw/tmax_log/$BKDAY/$HOST.ulog.$BKDAY.tar.gz"
    if [ $? -eq 0 ]; then
     rm /sw/oframe/online_log/ulog/ulog.$BKDAY.tar.gz
    fi

    BKDAY1="`/usr/local/bin/Dday -2 | cut -c1,2,3,4,6,7,9,10`"

    su - xadmjhm -c "scp /sw/oframe/online_log/olog/svcolog.$BKDAY1.gz libcodbp2:/sw/tmax_log/$BKDAY/$HOST.svcolog.$BKDAY.gz"
    if [ $? -eq 0 ]; then
     rm /sw/oframe/online_log/olog/svcolog.$BKDAY1.gz
    fi
    ;;
  
    LIBCODBP1|LIBCODBT1)

    su - xadmjhm -c "scp /sw/oframe/online_log/slog/slog.$BKDAY.gz libcodbp2:/sw/tmax_log/$BKDAY/$HOST.slog.$BKDAY.gz"
    if [ $? -eq 0 ]; then
     rm /sw/oframe/online_log/slog/slog.$BKDAY.gz
    fi

    su - xadmjhm -c "scp /sw/oframe/online_log/ulog/ulog.$BKDAY.tar.gz libcodbp2:/sw/tmax_log/$BKDAY/$HOST.ulog.$BKDAY.tar.gz"
    if [ $? -eq 0 ]; then
     rm /sw/oframe/online_log/ulog/ulog.$BKDAY.tar.gz
    fi
    ;;
  
esac
