su - controlm -c "sqlplus '/as sysdba' @/sw/ctm/controlm/listts_etc.controlm.sql"
