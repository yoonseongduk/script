#!/bin/ksh

scp libcodbp2:/sw/swwork/Online_resp.txt /sw/tivoli/webdocs/apache/htdocs/LIG/report/day_report/data/20080512.online_resp
scp libcodbp2:/sw/swwork/Online_resp_detail.txt /sw/tivoli/webdocs/apache/htdocs/LIG/report/day_report/data/20080512.onlin_detail
