#!/bin/ksh

BKDAY=`Dday -2 | cut -c1,2,3,4,6,7,9,10`

cd /sw/oframe/online_log/olog

gzip -c9 svcolog.$BKDAY > svcolog.$BKDAY.gz

ls -al svcolog.$BKDAY.gz
