#!/bin/ksh
SCRIPT_HOME='/sw/BizMaster4/Agent/script'
HOSTNAME=`hostname`
export SCRIPT_HOME
ls $SCRIPT_HOME'/'$HOSTNAME'/' | cut -f1
