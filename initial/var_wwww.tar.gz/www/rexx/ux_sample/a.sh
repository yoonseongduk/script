#!/usr/bin/sh

mount >> $OFILE
