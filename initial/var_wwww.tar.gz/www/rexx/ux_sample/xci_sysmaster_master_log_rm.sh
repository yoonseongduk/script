#!/bin/ksh

RMDAY="`/usr/local/bin/Dday -4 | cut -c1,2,3,4,6,7,9,10`"

cd /sw/openframe/master/logs

rm elog.$RMDAY
rm smlog.$RMDAY 
