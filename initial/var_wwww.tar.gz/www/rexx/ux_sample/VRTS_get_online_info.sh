#!/bin/sh

# Veritas StorageFoundation PM script
#
# Servers with Veritas product:
#    p595 #1, #2: LIBCOAPP1, LIBCODBP1, LIBCOAPP2, LIBCODBP2
#    p595 #3: LIBCOSVD1, LIBCOAPT1, LIBCOAPT2, LIBCODBT1, LIBMASVP1
#    p570 #1: LIBMASVP2, LIBMASVP3, LIBMASVD1, LIBDWP1
#    p570 #2: LIBEXAPP1, LIBEXDBP1, LIBBAAPP1, LIBBADBP2, LIBBASVT1
#    p570 #3: LIBEXAPP2, LIBEXDBP2, LIBBAAPP2, LIBBADBP1, LIBEXSVT1 
#
# 2007.01.17 Go Kil Pyo (3ssoft)

PATH="/usr/bin:/sbin:/opt/VRTS/bin:/opt/VRTSvcs/bin"
export PATH

HOSTNAME=`hostname`
DATE=`date '+%y%m%d'`
OFILE=/ISC/shell/"${HOSTNAME}_${DATE}.log"

echo "[HOSTNAME : ${HOSTNAME}]" > $OFILE
# Volme Manager
echo "\n## License " >> $OFILE
vxlicrep >> $OFILE
echo "\n## VM Process " >> $OFILE
ps -ef |grep -i vx >> $OFILE
echo "\n## Disks " >> $OFILE
vxdisk list >> $OFILE
echo "\n## DG info" >> $OFILE
vxdg list >> $OFILE
echo "\n## Volume info 1" >> $OFILE
vxprint -th >> $OFILE
echo "\n## Volume info 2" >> $OFILE
vxprint -v >> $OFILE
# File System
echo "\n\n\n## Disk Free " >> $OFILE
df -g >> $OFILE
echo "\n## Mount info" >> $OFILE
/usr/sbin/mount >> $OFILE

# VCS 
which lltstat >/dev/null
if [ $? -ne 0 ]; then
  echo "\n## VCS is not installed on this server." >> $OFILE
else
  echo "\n\n\n## VCS engine " >> $OFILE
  ps -ef |grep -i vcs >> $OFILE
  echo "\n## Heartbeat " >> $OFILE
  lltstat -n >> $OFILE
  gabconfig -a >> $OFILE
  echo "\n## Cluster status" >> $OFILE
  hastatus -sum >> $OFILE
  echo "\n## Cluster messages" >> $OFILE
  tail -100 /var/VRTSvcs/log/engine_A.log >> $OFILE
  echo "\n[EOF]" >> $OFILE
  if [ -f /etc/vxfendg ]; then
    echo "\n## vxdisk -o alldgs list |grep vxfen" >> $OFILE
    vxdisk -o alldgs list | grep vxfen >> $OFILE
    echo "\n## vxfenadm -g all -f /etc/vxfentab"   >> $OFILE
    vxfenadm -g all -f /etc/vxfentab >> $OFILE
  fi
fi
