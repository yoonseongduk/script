#!/bin/ksh

#
# Transfer errpt -s MMDDhhmmYY result to lghprt01 server
#
# Runs on everyday 07:30, cron
#
# Roh Tae-won 2005.03.31

LANG=en_US

BASEDIR=/ISC/shell
LAST_CHECKTIME_FILE=$BASEDIR/errpt_lastcheck.dat
cNode=`hostname`

#######################################################
# Phase 1/5: Process last errpt check time
#######################################################
if [ -f $LAST_CHECKTIME_FILE ] ; then
  ERRPT_FROM=`cat $LAST_CHECKTIME_FILE`
else
  ERRPT_FROM=`date +%m%d0000%y`
fi

#LOGFILE_NAME=errpt_${cNode}_${ERRPT_FROM}.log
LOGFILE_NAME=errpt_${cNode}.log
LOG=$BASEDIR/$LOGFILE_NAME

#######################################################
# Phase 2/5: Save errpt result and check time
#######################################################
errpt -s $ERRPT_FROM | uniq > $LOG
date +"%m%d%H%M%y" > $LAST_CHECKTIME_FILE

#######################################################
# Phase 3/5: Add message if there's no errpt result
#######################################################
LOG_LINE_COUNT=`wc $LOG | awk '{print $1}`
if [ $LOG_LINE_COUNT -eq 0 ] ; then
  echo "No errors since $ERRPT_FROM" >> $LOG
fi



#######################################################
# Phase 4/5: Transfer errpt result
#######################################################
#cd $BASEDIR
#ftp -n $FTP_DEST << ERRPT_FTP
#user $FTPID $FTPPASS
#cd $DESTDIR
#put $LOGFILE_NAME
#bye
#ERRPT_FTP

#######################################################
# Phase 5/5: Delete log file
#######################################################
#\rm $LOG

