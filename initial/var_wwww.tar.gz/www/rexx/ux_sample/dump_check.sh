sysdumpdev -l 
sysdumpdev -e 
lsvg -l rootvg
lsvg rootvg
