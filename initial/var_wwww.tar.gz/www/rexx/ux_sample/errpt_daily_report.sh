#!/bin/ksh

# report output file
#         : /sw/tivoli/webdocs/apache/htdocs/LIG/report/day_report/data/YYYYMMDD.errpt
# Roh Tae-won 2006.05.25


BASEDIR=/ISC/shell
DATADIR=$BASEDIR/errpt
LOG=$BASEDIR/errpt_daily_report.log

HOST_LIST=$BASEDIR/errpt_daily_hosts.conf

REPORT_TMP=$BASEDIR/errpt_daily_report_`date +%m%d_%H%M`.tmp
REPORTDIR=/sw/tivoli/webdocs/apache/htdocs/LIG/report/day_report/data
REPORTFILE=$REPORTDIR/`date +%Y%m%d`.errpt

echo "### START script[$0] on `date` ### " >> $LOG

rm -f $DATADIR/errpt_*.log

if [ ! -d $REPORTDIR ]; then
  echo "WARNING: Report directory [$REPORTDIR] does not exist. exiting..." >> $LOG
  exit 1
fi

echo					>> $REPORT_TMP
echo					>> $REPORT_TMP
echo "################################" >> $REPORT_TMP
echo " errpt report at `date`         "	>> $REPORT_TMP
echo "################################" >> $REPORT_TMP

cat $HOST_LIST | while read host
do
  echo $host
  ssh -f $host /ISC/shell/errpt_daily.sh
  sleep 10 
  if [ "$host" = "LIBCODBP1" -o "$host" = "LIBCODBP2" ]; then
    sleep 30
  fi

  scp $host:/ISC/shell/errpt_$host.log $DATADIR
  if [ $? -ne 0 ]; then
    echo "scp file[errpt_$host.log] failed..." >> $LOG
  else
   ls -al $DATADIR/errpt_$host.log >> $LOG
  fi
  sleep 1

  echo 				>> $REPORT_TMP
  echo 				>> $REPORT_TMP
  echo "#### $host ####" 	>> $REPORT_TMP
  echo 				>> $REPORT_TMP

  if [ -r $DATADIR/errpt_$host.log ]; then
    cat $DATADIR/errpt_$host.log 	>> $REPORT_TMP
  else
    echo "ERROR: errpt result($DATADIR/errpt_$host.log] does not exist." >> $REPORT_TMP
  fi

  sleep 1
done

sleep 1

cat $BASEDIR/errpt_daily_report_*.tmp >> $REPORTFILE
rm -f $BASEDIR/errpt_daily_report_*.tmp

echo "### END script[$0] on `date` ### " >> $LOG
