#!/bin/ksh

#
# Netbackup LTO drive utilization logging script.
#
# Roh Tae-won 2006.08.22

LOG=/ISC/shell/NBU_drv_util_logging.dat

date +%m%d_%H%M >> $LOG
#/usr/openv/volmgr/bin/vmoprcmd  |grep -i active |grep rmt >> $LOG
/usr/openv/volmgr/bin/vmoprcmd  |grep -i active |egrep -v -e "^[A-Z]" >> $LOG
