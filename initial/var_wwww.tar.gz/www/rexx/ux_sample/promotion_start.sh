#!/bin/ksh

####### VERIRY ##############
./promotion_verify.sh > /dev/null 2>&1
VERIFY=$?
if [ $VERIFY -eq 0 ]
then
        echo "PromotionServer is already running, It can't be restarted!"
        exit 255
fi

####### Launch PromotionServer #######

nohup PromotionServer 6000 &

####### VERIRY ##############
sleep 5
./promotion_verify.sh > /dev/null 2>&1
VERIFY=$?
if [ $VERIFY -eq 0 ]
then
        echo "PromotionServer started successfully!"
        exit 0
else
        echo "PromotionServer launch failed!"
        exit 255
fi

