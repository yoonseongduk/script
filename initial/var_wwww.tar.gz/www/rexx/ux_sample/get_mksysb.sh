#!/bin/ksh

DATE=`date '+%y%m%d'`
TARGET_DIR=/ISC/log/mksysb
TARGET_LOG=$TARGET_DIR/mksysb.log.$DATE
DEVICE=`lsdev -Cc tape| grep Available | grep "4mm Tape Drive" | awk '{print $1}'`

echo "$(date +%D:%T) Backup is started." 
echo "$(date +%D:%T) Backup is started." >> $TARGET_LOG
echo "-------------------------------------------" >> $TARGET_LOG

/usr/bin/mksysb  '-e'  '-i'   /dev/$DEVICE 1>> $TARGET_LOG 2>> $TARGET_LOG

echo "$(date +%D:%T) Backup is ended."
echo "$(date +%D:%T) Backup is ended." >> $TARGET_LOG
echo "-------------------------------------------" >> $TARGET_LOG

tctl -f /dev/$DEVICE offline 1>> $TARGET_LOG 2>> $TARGET_LOG
echo "$(date +%D:%T) Tape is ejected."
echo "$(date +%D:%T) Tape is ejected." >> $TARGET_LOG

