#!/bin/ksh

. /etc/Tivoli/lcf/1/lcf_env.sh
export LANG=ko_KR

WPOST=${LCF_BINDIR}/../bin/wpostemsg
LOGFILE=/tmp/tivoli_sms_msg.log 

date    >> $LOGFILE
echo $* >> $LOGFILE
echo " $* : Permanent RemoteServer SMS_MSG"                    >> $LOGFILE
echo " $1 : Permanent RemoteServer SMS_MSG"                    >> $LOGFILE
echo "=======================================================" >> $LOGFILE
 
# $WPOST -r CRITICAL -m "$1 $msg" hostname=$HOSTNAME device_name=$1 Errpt_Hardware_Error ERRPT
$WPOST $1 $2 $3 $4 $5 $6 $7 $8 $9 ${10} ${11} ${12} ${13}


exit 0

