#!/bin/ksh

BKDAY="`/usr/local/bin/Dday -2 | cut -c6,7,9,10``/usr/local/bin/Dday -2 | cut -c1,2,3,4`"

cd /sw/oframe/online_log/ulog

tar -cvf - *$BKDAY.out *$BKDAY.err | gzip -9 > ulog.$BKDAY.tar.gz

ls -al ulog.$BKDAY.tar.gz
