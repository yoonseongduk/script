#!/bin/ksh

HOST=`uname -n`
OSLEVEL=`oslevel`
DD=$(date +%d)
MM=$(date +%m)
YY=$(date +%Y)
HHMMSS=$(date +%T)
MMDD=$MM$DD
YYMMDD=$YY$MMDD
TEAM=$TEAM
ACCT=$ACCT
OS=$OS
OP=$OP
SH_VER=$SH_VER
ora="NO"
cpu=0

# ftp_rtn  start # ftp record send
ip="165.244.226.12"
id="xadmasc"
pass="asc65036"
indd_ftp="/ISC/audit/out_all/${YYMMDD}_all_IT3.sql"
outdd_ftp="/home1/admgroup/xadmasc/hcdatabk/${YYMMDD}_all_IT3.sql"

ftp -n ${ip} << EOF
user $id $pass
put $indd_ftp $outdd_ftp
EOF

exit
