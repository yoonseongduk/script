#!/bin/ksh

# Delete old control-m ARCHIVE files
#
# Youn Jihoon 2008.05.19

cd /sw/ctm/controlm/ARCHIVE
DATE=`date`
echo "## File list to delete at $DATE ###"
find . -name '*.dbf' -mtime +3 -exec ls -l {} \;
echo "## File list END ###"
find . -name '*.dbf' -mtime +3 -exec rm {} \;
echo

