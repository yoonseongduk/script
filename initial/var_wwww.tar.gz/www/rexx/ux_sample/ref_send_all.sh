#!/bin/ksh
INDD=/usr/local/bin
OUTDD=/usr/local/bin
HOST_LIST=/ISC/shell/hosts.list

cat $HOST_LIST | while read host
do
  echo $host
  scp  $INDD/ref $host:$OUTDD/ref 
  sleep 1
done

exit 
