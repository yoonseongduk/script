cd /usr/openv/volmgr/bin
cp ltid ltid.20060726
mv ltid.rs6000 ltid
ls -al ltid*
