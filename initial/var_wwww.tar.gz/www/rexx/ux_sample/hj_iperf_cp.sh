#!/usr/bin/ksh

for HOSTNAME in `cat /ISC/shell/hj_iperf_cp.list`
do
echo $HOSTNAME

#ssh $HOSTNAME rm /sw/tivoli/iperf*
#ssh $HOSTNAME mkdir /sw/tivoli/MAS
#ssh $HOSTNAME ls -lt /sw/tivoli
#scp /sw/tivoli/MAS/iperfcoll $HOSTNAME:/sw/tivoli/MAS/iperfcoll
#scp /sw/tivoli/MAS/iperfsend $HOSTNAME:/sw/tivoli/MAS/iperfsend
#scp /sw/tivoli/MAS/iperfstart $HOSTNAME:/sw/tivoli/MAS/iperfstart

ssh $HOSTNAME /sw/tivoli/MAS/iperfstart
done
