#!/bin/ksh
BASEDIR=/ISC/shell
BASEDIR2=/usr/local/bin 
HOST_LIST=$BASEDIR/hosts.list

cat $HOST_LIST | while read host
do
  echo $host
  scp  $BASEDIR/task.rexx      $host:$BASEDIR/task.rexx
  scp  $BASEDIR/ts.sh          $host:$BASEDIR/ts.sh 
  scp  $BASEDIR2/task.rexx     $host:$BASEDIR2/task.rexx 
  echo "return code: $$ " 
  sleep 1
done

exit 
