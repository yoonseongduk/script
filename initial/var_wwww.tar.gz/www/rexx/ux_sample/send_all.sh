#!/bin/ksh
BASEDIR1=/ISC/shell
BASEDIR2=/usr/local/bin 
BASEDIR3=/etc/rc.d/rc2.d
BASEDIR4=/ISC/shell/aixadmjm_os_nic_audit.sh
HOST_LIST=$BASEDIR1/hosts.list
MEM0=doc_sdy      
MEM1=master.rexx    
MEM2=nmon
MEM3=S10iplinfo

cat $HOST_LIST | while read host
do
  echo $host
#  scp  $BASEDIR1/$MEM1     $host:$BASEDIR1/$MEM1       
#  scp  $BASEDIR2/$MEM2     $host:$BASEDIR2/$MEM2       
#  scp  $BASEDIR3/$MEM3     $host:$BASEDIR3/$MEM3       
   scp  $BASEDIR4           $host:$BASEDIR4             
done

exit 
