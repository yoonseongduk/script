#!/bin/ksh

PID_COUNT=`ps -ef | grep "PromotionServer" | grep -v grep | wc -l`
if [ $PID_COUNT -ge 1 ]
then
        echo "PromotionServer is alive."
        exit 0
else
        echo "PromotionServer is dead."
        exit 255
fi
