#!/bin/ksh

#
# Tivoli message test script
#
# Roh Tae-won 2006.08.22
#

. /etc/Tivoli/lcf/1/lcf_env.sh

export LANG=ko_KR
WPOST=${LCF_BINDIR}/../bin/wpostemsg
HOSTNAME=`hostname`
LOG=/ISC/shell/Tivoli_message_test.log

$WPOST -r FATAL -m "Tivoli message test. Ignore this..." hostname=$HOSTNAME Backup_Failed EVENT
$WPOST -r CRITICAL -m "Tivoli message test. Ignore this..." hostname=$HOSTNAME Backup_Failed EVENT

DATE=`date "+%m/%d %H:%M"`
printf "%-15s Tivoli message test ended." "$DATE" >> $LOG
