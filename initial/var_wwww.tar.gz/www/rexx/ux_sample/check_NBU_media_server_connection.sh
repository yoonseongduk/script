#!/bin/ksh

#
# Roh Tae-won 2008.03.24
#

nbemmcmd -listhosts | grep ^media | awk '{print "bpclntcmd -get_remote_host_version "$2}' |sh -x
