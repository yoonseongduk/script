#!/usr/bin
 grep  'PROC,'  /ISC/nmon/out/LIBCODBP1_0703*.nmon > /sw/swwork/runq_nmon.out
