#!/usr/bin/ksh

make_disk()
{
        lspv | wc -l > $NDISK
        for DISK in `lspv | awk '{print $1}'`
        do
                lsattr -El $DISK | grep size_in_mb | awk '{print $2}' >> $PDISK
        done

        for VG in `lsvg -o`
       do
               lsvg $VG | grep "TOTAL PPs" | awk '{print $7}' | awk -F\( '{print $2}' >> $VGTOTAL
               lsvg $VG | grep "USED PPs" | awk '{print $6}' | awk -F\( '{print$2}' >> $VGUSED
       done

       df -k | grep -v "Mounted on" | awk '{print $2}' >> $JFSTOTAL
       df -k | grep -v "Mounted on" | awk '{print $3}' >> $JFSFREE
}

send_mail()
{
       \rm $TEMPFILE1
       for I in `ls /ISC/report/cicsreport*`
       do
               echo "$I" >> $TEMPFILE1
               cat   $I  >> $TEMPFILE1
       done

       mailx -s CICS_REPORT shylee@lgcns.com < $TEMPFILE1
       mailx -s CICS_REPORT hjinpark@lgcns.com < $TEMPFILE1
}

CICSREPORT="/ISC/report/cicsreport"
TEMPFILE1="/ISC/report/tempfile1"
SCRIPTDIR="/bkup/MSCMON/scripts"

LOGDIR="/bkup/MSCMON/log"
NDISK="${LOGDIR}/ndisk"
PDISK="${LOGDIR}/pdisk"
VGTOTAL="${LOGDIR}/vgtotal"
VGUSED="${LOGDIR}/vgused"
JFSTOTAL="${LOGDIR}/jfstotal"
JFSFREE="${LOGDIR}/jfsfree"

\rm $NDISK $PDISK $VGTOTAL $VGUSED $JFSTOTAL $JFSFREE

make_disk
${SCRIPTDIR}/make_summary.pl > ${CICSREPORT}`hostname`
#send_mail
exit
