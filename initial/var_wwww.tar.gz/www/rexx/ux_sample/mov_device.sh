TARGET_HOST=LIBMASVP3

DATE=`date '+%y%m%d'`
TARGET_DIR=/ISC/log/mksysb
TARGET_LOG=$TARGET_DIR/moveSlot.log.$DATE

if [ ! -d $TARGET_DIR ]
then
        mkdir -p $TARGET_DIR
fi

if [ ! -f $TARGET_LOG ]
then
        touch $TARGET_LOG
fi

/ISC/dlpar/bin/moveSlot.pl -host $TARGET_HOST  1>> $TARGET_LOG   2>>$TARGET_LOG
RC=$?


DEVICE=`lsdev -Cc tape| grep Available | grep "4mm Tape Drive" | awk '{print $1}'`


#echo $RC $DEVICE

if [ "$DEVICE" != ""  ]
then
	echo "-------------------------------------------" >> $TARGET_LOG
	echo "$(date +%D:%T) Device $DEVICE is moved to $TARGET_HOST successfully."
	echo "$(date +%D:%T) Device $DEVICE is moved to $TARGET_HOST successfully."   1>> $TARGET_LOG   2>>$TARGET_LOG
        echo "-------------------------------------------" >> $TARGET_LOG	
else
	echo "-------------------------------------------" >> $TARGET_LOG
	echo "$(date +%D:%T) Device $DEVICE is not moved to $TARGET_HOST successfully."
	echo "$(date +%D:%T) Device $DEVICE is not moved to $TARGET_HOST successfully."   1>> $TARGET_LOG   2>>$TARGET_LOG
	echo "-------------------------------------------" >> $TARGET_LOG
fi
