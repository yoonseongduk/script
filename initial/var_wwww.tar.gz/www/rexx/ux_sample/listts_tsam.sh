#/usr/bin/ksh
chmod 755 /ISC/shell/listts_etc.sub2
START_TIME_SEC=$( date +%s )
UNDO_REC=$( su - oframe "-c /ISC/shell/listts_etc.sub2 sys/oframe@LOCAL" |grep -i undo )
END_TIME_SEC=$( date +%s )
(( RESP_TIME = $END_TIME_SEC - $START_TIME_SEC ))
DATE_TIME=$( date "+%Y%m%d %T" )
echo "$DATE_TIME $UNDO_REC $RESP_TIME"
