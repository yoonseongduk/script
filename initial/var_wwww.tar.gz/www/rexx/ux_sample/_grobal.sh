#!/bin/ksh

substr()
{
        typeset _str="$1"
        typeset -i _strlen=${#_str}

        typeset -i _offset="${2:-0}"
        typeset -i _sublen="${3}"

        typeset -i _rlen
        ((_rlen=_strlen-_offset))

        typeset -R${_rlen} _substr=${_str}
        typeset -L${_sublen} _substr=${_substr}

        echo $_substr
}

dup_count()
{
# stdin/stdout
# function:  sort�� input record�� dup count�� �߰��Ͽ� output �Ѵ�.
#
        typeset -i _i
        typeset _x_=""       

        _i=0;
        while read _x
        do
          if [ $_x != $_x_ ] ; then 
             _i=0
          fi
          (( _i = $_i + 1 ))
          print $_x":"$_i
          _x_=$_x 
        done
}

nodup_count()
{                   
# stdin/stdout
# function:  sort�� input record�� dup count�� �߰��Ͽ� ������ dup report �� output �Ѵ�.
#
        typeset -i _i         #     dup record count
        typeset -i _c         # input   record count
        typeset _x_=" "       #         before record ..
                              # _x     current record ..
        typeset _x_out=" "    # current output record ..
        typeset _x_bak=" "    # keep    before record ..

        _i=0;_c=0
        while read _x
        do
          (( _c = $_c + 1 ))
          if [[ "$_x" != "$_x_" ]] ; then
             _i=0; _x_bak=$_x_         # keep before record 
             if [ $_c -gt 1 ] ; then 
                print $_x_out          # current record
             fi
          fi
          (( _i = $_i + 1 ))
          _x_=$_x; _x_out=$_x":"$_i
        done
        if [[ $_x  != $_x_bak ]] ; then 
           print $_x_out
        fi

}

