#!/opt/freeware/rexx/bin/rexx

/* ------------------------------------------------------------------------*/
/* DB2 Copy : from LIBCODBP1 to LIBCODBT1                                  */
/* Created by sdy 2007.05.04                                               */
/*                                                                         */
/* 1:/dbpa/archive1/dbpainst/NODE0000/....                                 */
/* 2:/dbpa/loadcopy/....                                                   */
/*                                                                         */
/* LAST_F �� yyyymmdd   hh:mm �� update �Ͽ� copy start file�� �����Ѵ�.   */
/*                                                                         */
/*                                                                         */
/* ------------------------------------------------------------------------*/ 


FS1          = "/dbpa/archive1"
FS2          = "/dbpa/loadcopy"

DD1          =  FS1"/dbpainst/DBPA/NODE0000"
DD2          =  FS2

DD1_LOCK_F   =  DD1"/COPY_LOCK_FILE"
DD2_LOCK_F   =  DD2"/COPY_LOCK_FILE"

DD1_COPY_F   =  DD1"/COPY_FILE"
DD2_COPY_F   =  DD2"/COPY_FILE"

DD1_LAST_F   =  DD1"/LAST_FILE"    /* 20070504    19:19      209723392   FS1          */
DD2_LAST_F   =  DD2"/LAST_FILE"    /* 20070504    19:19      209723392   FS2          */


       ADDRESS SYSTEM 'date'


       ADDRESS SYSTEM 'cat 'DD1_LAST_F WITH OUTPUT STEM tmpa.
       if tmpa.1 = 'TMPA.1'  then FILTER_REC1 = '00000000'
                             else FILTER_REC1  = tmpa.1
       say FILTER_REC1

       if LOCK_CHECK1() = 'not found' then do 
          msg = 'lock file check ... ok .. process continue'
          say msg
          rc1 = LOCK_CREATE1()
          rc2 = SELECT_FILE1()
          rc3 = DB2_COPY1() 
          rc9 = LOCK_DELETE1()  
       end
       else do
          msg = 'lock file founded .....  process terminate' 
          say msg
       end

       ADDRESS SYSTEM 'cat 'DD2_LAST_F WITH OUTPUT STEM tmpa.
       if tmpa.1 = 'TMPA.1'  then FILTER_REC2 = '00000000'
                             else FILTER_REC2  = tmpa.1
       say FILTER_REC2
       if LOCK_CHECK2() = 'not found' then do 
          msg = 'lock file check ... ok .. process continue'
          say msg
          rc1 = LOCK_CREATE2()
          rc2 = SELECT_FILE2()
          rc3 = DB2_COPY2() 
          rc9 = LOCK_DELETE2()  
       end
       else do
          msg = 'lock file founded .....  process terminate' 
          say msg
       end

exit
 


SELECT_FILE1:
 ADDRESS SYSTEM "ls -altrR "DD1 WITH OUTPUT STEM tmpa.

 tmpb.0 = 0; j = 1; dirx = 'DIRX'
 do i = 1 to tmpa.0
    select 
      when substr(tmpa.i,1,1) =     'd' then A = null   /* delete */
      when substr(tmpa.i,1,5) = 'total' then A = null   /* delete */
      when  index(tmpa.i,FS1)  =     1  then dirx = word(tmpa.i,1)
      otherwise do
                  if dirx            = 'DIRX'  then dirx = DD1
                  if index(dirx,':') >     0   then parse value dirx with dirx ':' 
                  parse value tmpa.i with a b c d fsize tail 
                  parse value tail   with mm dd ytime fname
                  if mm = ' ' then A = null
                              else do
                                   yyyymmdd = SET_DATE()
                                   tmpb.j = yyyymmdd ' ' right(ytime,6) ' ' right(fsize,12) ' ' left(fname,30) ' ' dirx
                                   j = j + 1
                              end
                end
    end  
 end
 tmpb.0 = j - 1

/* ADDRESS SYSTEM 'sort ' WITH INPUT STEM tmpb. OUTPUT STEM tmpc. */

 j = 1 
 do i = 1 to tmpb.0
    if ( ( index(tmpb.i,"/dbpa/archive1/dbpainst/DBPA/NODE0000/C0") > 0 ) & ( tmpb.i > FILTER_REC1) ) then do 
       tmpc.j = tmpb.i
       say "1 " tmpc.j; j = j + 1
    end
 end
 tmpc.0 = j - 1

 tmpa.0 = 0; j = 1; DEL_SUM_BYTE = 0; DEL_SUM = 0
 do i = 1 to tmpc.0
    parse value tmpc.i with yyyymmdd ytime fsize tail
    parse value tail   with fname    dirx  tail

    tmpa.j = dirx'/'fname
    j = j + 1

 end
 tmpa.0 = j - 1

 say 'i = ' i  'tmpc.0 = 'tmpc.0

 ADDRESS SYSTEM 'cp /dev/null ' DD1_COPY_F

 do i = 1 to tmpa.0
    rec = "scp -p" tmpa.i "LIBCODBT1:/dbpa/archive1/dbpainst/DBPA/NODE0000/ARCHLOST/"
    rc = lineout(DD1_COPY_F,rec)
 end
 i     = tmpc.0
 say i 
 if (tmpc.0 > 1) then rc  = lineout(DD1_LAST_F,tmpc.i,1)
 
return(0)


SELECT_FILE2:
 ADDRESS SYSTEM "ls -altr "DD2 WITH OUTPUT STEM tmpa.

 tmpb.0 = 0; j = 1; dirx = 'DIRX'
 do i = 1 to tmpa.0
    select 
      when substr(tmpa.i,1,1) =     'd' then A = null   /* delete */
      when substr(tmpa.i,1,5) = 'total' then A = null   /* delete */
      when  index(tmpa.i,FS2)  =     1  then dirx = word(tmpa.i,1)
      otherwise do
                  if dirx            = 'DIRX'  then dirx = DD2
                  if index(dirx,':') >     0   then parse value dirx with dirx ':' 
                  parse value tmpa.i with a b c d fsize tail 
                  parse value tail   with mm dd ytime fname
                  if mm = ' ' then A = null
                              else do
                                   yyyymmdd = SET_DATE()
                                   tmpb.j = yyyymmdd ' ' right(ytime,6) ' ' right(fsize,12) ' ' left(fname,60) ' ' dirx
                                   j = j + 1
                              end
                end
    end  
 end
 tmpb.0 = j - 1


/* ADDRESS SYSTEM 'sort ' WITH INPUT STEM tmpb. OUTPUT STEM tmpc. */

 j = 1 
 do i = 1 to tmpb.0
    if ( ( index(tmpb.i,"DBPA.4.dbpainst.NODE0000") > 0 ) & ( tmpb.i > FILTER_REC2) ) then do 
       tmpc.j = tmpb.i
       say "2 " tmpc.j; j = j + 1
    end
 end
 tmpc.0 = j - 1

 tmpa.0 = 0; j = 1; DEL_SUM_BYTE = 0; DEL_SUM = 0
 do i = 1 to tmpc.0
    parse value tmpc.i with yyyymmdd ytime fsize tail
    parse value tail   with fname    dirx  tail

    tmpa.j = dirx'/'fname
    j = j + 1

 end
 tmpa.0 = j - 1

 say 'i = ' i  'tmpc.0 = 'tmpc.0

 ADDRESS SYSTEM 'cp /dev/null ' DD2_COPY_F

 do i = 1 to tmpa.0
    rec = "scp -p" tmpa.i "LIBCODBT1:"tmpa.i                                            
    rc = lineout(DD2_COPY_F,rec)
 end
 i     = tmpc.0
 if (tmpc.0 > 1) then rc  = lineout(DD2_LAST_F,tmpc.i,1)
 
return(0)








SET_DATE:
  mm = SET_MM()
  if index(ytime,':') = 3 then do 
                                  cur_yymmdd = date('s')
                                  cur_yyyy   = substr(cur_yymmdd,1,4)
                                  cur_mm     = substr(cur_yymmdd,5,2)
                                  if mm > cur_mm then yyyy = cur_yyyy - 1
                                                 else yyyy = cur_yyyy
                               end
                          else yyyy = ytime
  mm = SET_MM_REV()
  yyyymmdd = date('s',dd' 'mm' 'yyyy,'n')
return(yyyymmdd)

SET_MM:
  select 
    when (mm = 'Jan') then mm= '01'
    when (mm = 'Feb') then mm= '02'
    when (mm = 'Mar') then mm= '03'
    when (mm = 'Apr') then mm= '04'
    when (mm = 'May') then mm= '05'
    when (mm = 'Jun') then mm= '06'
    when (mm = 'Jul') then mm= '07'
    when (mm = 'Aug') then mm= '08'
    when (mm = 'Sep') then mm= '09'
    when (mm = 'Oct') then mm= '10'
    when (mm = 'Nov') then mm= '11'
    when (mm = 'Dec') then mm= '12'
    otherwise              mm= mm  
  end                              
return(mm)

SET_MM_REV:
  select 
    when (mm = '01') then mm= 'Jan'
    when (mm = '02') then mm= 'Feb'
    when (mm = '03') then mm= 'Mar'
    when (mm = '04') then mm= 'Apr'
    when (mm = '05') then mm= 'May'
    when (mm = '06') then mm= 'Jun'
    when (mm = '07') then mm= 'Jul'
    when (mm = '08') then mm= 'Aug'
    when (mm = '09') then mm= 'Sep'
    when (mm = '10') then mm= 'Oct'
    when (mm = '11') then mm= 'Nov'
    when (mm = '12') then mm= 'Dec'
    otherwise             mm= mm
  end 
return(mm)


LOCK_CHECK1:
  ADDRESS SYSTEM "ls "DD1 WITH OUTPUT STEM tmp.
  rr = 'not found'
  do i = 1 to tmp.0
     if index(tmp.i,LOCK_F) > 0 then rr = 'found'
  end
return(rr)

LOCK_CREATE1:
  ADDRESS SYSTEM "ps -ef|grep .rexx| grep -v grep > "DD1_LOCK_F
return(rc)

LOCK_DELETE1:
  ADDRESS SYSTEM "rm "DD1_LOCK_F
return(rc)



 
LOCK_CHECK2:
  ADDRESS SYSTEM "ls "DD2 WITH OUTPUT STEM tmp.
  rr = 'not found'
  do i = 1 to tmp.0
     if index(tmp.i,LOCK_F) > 0 then rr = 'found'
  end
return(rr)

LOCK_CREATE2:
  ADDRESS SYSTEM "ps -ef|grep .rexx| grep -v grep > "DD2_LOCK_F
return(rc)

LOCK_DELETE2:
  ADDRESS SYSTEM "rm "DD2_LOCK_F
return(rc)
 

DB2_COPY1: 
  ADDRESS SYSTEM "chmod 744 "DD1_COPY_F
  ADDRESS SYSTEM "sh -x     "DD1_COPY_F
  ADDRESS SYSTEM "ssh LIBCODBT1 chown -R dbpainst:db2grp /dbpa/archive1/dbpainst/DBPA/NODE0000/ARCHLOST" 
return(rc)


DB2_COPY2: 
  ADDRESS SYSTEM "chmod 744 "DD2_COPY_F
  ADDRESS SYSTEM "sh -x     "DD2_COPY_F
  ADDRESS SYSTEM "ssh LIBCODBT1 chown -R dbpainst:db2grp /dbpa/loadcopy" 
return(rc)


