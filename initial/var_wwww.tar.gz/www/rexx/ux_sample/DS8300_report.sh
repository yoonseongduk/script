#!/bin/ksh

#
# for Monthly report of external disk
#
# 2007.8.31 Roh Tae-won

echo "###################################################"
echo " 1. Physical allocation of DS8300 in LIBMASVP2     "
echo "###################################################"
df.rexx  |grep "^#1 db_masvp2" |sum.rexx 3


echo "###################################################"
echo " 2. Total volume size of DS8300 in LIBMASVP2     "
echo "###################################################"
df.rexx  |grep "^#1 db_masvp2" |sum.rexx 4
echo

echo "###################################################"
echo " 3. Filesystem size by DBPM"
echo "###################################################"
df.rexx -g db_masvp2 |grep dbpm | sum.rexx 2

echo "Enter to continue..."
read DUMMY

echo "###################################################"
echo " 4. Filesystem USED by DBPM"
echo "###################################################"
df.rexx -g db_masvp2 |grep dbpm | sum.rexx 3


echo "###################################################"
echo " 5. Filesystem size/USED by i3"
echo "###################################################"
df.rexx -g i3

echo "Enter to continue..."
read DUMMY

echo "###################################################"
echo " 6. Filesystem size by Tivoli"
echo "###################################################"
df.rexx | egrep -e "tecinst|tec|tivoli" | sum.rexx 2


echo "###################################################"
echo " 7. Filesystem USED by Tivoli"
echo "###################################################"
df.rexx | egrep -e "tecinst|tec|tivoli" | sum.rexx 3

echo "Enter to continue..."
read DUMMY


echo "###################################################"
echo " 8. Filesystem size by BizMaster"
echo "###################################################"
df.rexx | egrep -e "bizm|proj|bizminst|projinst" | sum.rexx 2

echo "###################################################"
echo " 9. Filesystem USED by BizMaster"
echo "###################################################"
df.rexx | egrep -e "bizm|proj|bizminst|projinst" | sum.rexx 3


echo "Enter to continue..."
read DUMMY

echo "###################################################"
echo " 10. Filesystem size/USED by db2pe"
echo "###################################################"
df.rexx -g db2peusr

echo "###################################################"
echo " 11. Filesystem size/USED by QMF Jeus"
echo "###################################################"
df.rexx -g jeus


