#!/bin/ksh
# Run this in cron each night. It will replace the file each day with current
# levels of software and firmware.
# Blank line is placed between each section so we could use grep -p

HOSTNAME=`hostname -s`
#OUTPUT=/tmp/${HOSTNAME}.listhwlevels
OUTPUT=/ISC/log/${HOSTNAME}.listhwlevels

print "listhwlevels run on $HOSTNAME on `date`" > $OUTPUT
print >> $OUTPUT
print "SYSTEM ID" >> $OUTPUT
print "MODEL:`lsattr -El sys0 -a modelname | awk '{print $2}'`" >> $OUTPUT
print "SERIAL NO:`lsattr -El sys0 -a systemid | awk '{print $2}'`" >> $OUTPUT
print >> $OUTPUT
print "SYSTEM SETTINGS" >> $OUTPUT
lsattr -El sys0 >> $OUTPUT
print >> $OUTPUT
print "HARDWARE CONFIG" >> $OUTPUT
lscfg -vp >> $OUTPUT
print >> $OUTPUT
print "FILESYSTEM SETTINGS" >> $OUTPUT
/usr/bin/which df.rexx
rc=$?
if [ $rc -eq 0 ]; then
   /usr/local/bin/df.rexx >> $OUTPUT
else 
   df -kI >> $OUTPUT
fi
print >> $OUTPUT
print "ALL VOLUME GROUPS" >> $OUTPUT
lsvg >> $OUTPUT
print >> $OUTPUT
print "VOLUME GROUPS ONLINE" >> $OUTPUT
lsvg -o >> $OUTPUT
print >> $OUTPUT
print "LOGICAL VOLUMES" >> $OUTPUT
#for f in `lsvg -o`
#do
#  lsvg -l $f >> $OUTPUT
#done
print >> $OUTPUT
print "PAGING SPACES" >> $OUTPUT
lsps -a >> $OUTPUT
print >> $OUTPUT
print "NETWORK INTERFACES" >> $OUTPUT
ifconfig -a >> $OUTPUT
print >> $OUTPUT
print "EtherChannel Configuration" >> $OUTPUT
for number in `LANG=C lsdev -Cc adapter -s pseudo -t ibm_ech -F name|awk -F "ent" '{print $2}' | sort -n`
do
    channel="ent${number}"
    status=`lsdev -Cc adapter -s pseudo -t ibm_ech | grep $channel | awk '{ print $2 }'`
    echo 'EtherChannel / Link Aggregation: ' $channel  >> $OUTPUT
    echo 'Status: ' $status  >> $OUTPUT
    echo 'Attributes:'  >> $OUTPUT
    lsattr -El $channel -F "      attribute value description"  >> $OUTPUT
    echo ""  >> $OUTPUT
done
print >> $OUTPUT
print "NETWORK ROUTES" >> $OUTPUT
netstat -rn >> $OUTPUT
print >> $OUTPUT
print "MICROCODE LEVELS" >> $OUTPUT
lsmcode -A >> $OUTPUT
