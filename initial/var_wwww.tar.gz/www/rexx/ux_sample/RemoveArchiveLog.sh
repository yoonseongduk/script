#! /bin/ksh
cd $1
TARGET_DIR=$1
DIR_SIZE=`du -sk | awk '{print $1}'`
EIGHTY_PCT=$2

date >> RemoveArchiveLog.log
echo current_size : $DIR_SIZE , target_size : $EIGHTY_PCT >> RemoveArchiveLog.log

if [ ! -d $TARGET_DIR ]; then
  echo "$TARGET_DIR does not exist. Exiting..."
  exit 1
fi

while [ $DIR_SIZE -gt $EIGHTY_PCT ]
do
  FILE_NAME=`find $TARGET_DIR -name "*.LOG" | sort | head -1`
  rm -f $FILE_NAME
  echo removed_file : $FILE_NAME >> RemoveArchiveLog.log
  DIR_SIZE=`du -sk | awk '{print $1}'`
done
