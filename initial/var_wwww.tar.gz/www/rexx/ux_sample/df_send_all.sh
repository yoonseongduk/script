#!/bin/ksh
BASEDIR=/ISC/shell
TARGETDIR=/usr/local/bin
#HOST_LIST=$BASEDIR/errpt_daily_hosts.conf
HOST_LIST=$BASEDIR/hosts.list

cat $HOST_LIST | while read host
do
  echo $host
  scp  $TARGETDIR/df.rexx $host:$TARGETDIR/df.rexx
  echo "return code: $$ " 
  sleep 1
done

exit 
