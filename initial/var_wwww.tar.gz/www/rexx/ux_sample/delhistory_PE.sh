#! /bin/ksh
cd $1
TARGET_DIR=$1
DIR_SIZE=`du -sk | awk '{print $1}'`
THIRTY_PCT=$2

date >> delhistory_PE.log
echo current_size : $DIR_SIZE , target_size : $THIRTY_PCT >> delhistory_PE.log

if [ $THIRTY_PCT -lt $DIR_SIZE ]; then

  delhistory pmdb0001 0 > /dev/null 
  delhistory pmdb0002 0 > /dev/null
  delhistory pmdb0003 0 > /dev/null
  delhistory pmdb0005 0 > /dev/null

  echo " PE history data delete... OK"  >> delhistory_PE.log
  
fi
