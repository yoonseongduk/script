#!/bin/ksh

BASEDIR=/ISC/shell
DATADIR=$BASEDIR/errpt
HOST_LIST=$BASEDIR/errpt_daily_hosts.conf

cat $HOST_LIST | while read host
do
  echo $host
  ssh -f $host rm /ISC/shell/errpt_lastcheck.dat
  sleep 1
done

