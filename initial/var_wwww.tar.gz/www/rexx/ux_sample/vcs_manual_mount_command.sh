#!/bin/ksh

#
# Get command line output of CFS manual mount
#
# Roh Tae-won 2008.03.28

PATH=$PATH:/opt/VRTSvcs/bin/

DATE=`date +%Y%m%d`
OUTFILE=/ISC/shell/vcs_manual_mount_command.out

> $OUTFILE



#############################################################################################################
# Phase 1 : make CFS mount command
#############################################################################################################


hares -display -type CFSMount > /dev/null
CFS_MOUNT_POINT_EXIST=$?
############################################################################
# if CFS mount point exists 
############################################################################
if [ $CFS_MOUNT_POINT_EXIST -eq 0 ]; then
  hares -display -attribute ArgListValues -type CFSMount -sys `hostname` | grep -v ^# | while read LINE
  do
    MOUNT_POINT=`echo $LINE | awk '{print $4}'`
    BLOCK_DEVICE=`echo $LINE | awk '{print $5}'`
    MOUNT_OPTION=`echo $LINE | awk '{print $6}'`
    printf "mount -o %s -V vxfs %s \t%s\n" $MOUNT_OPTION $BLOCK_DEVICE $MOUNT_POINT >> $OUTFILE
  done
fi


#############################################################################################################
# Phase 2 : make local mount command
#############################################################################################################

# There are two kinds of "hares display" output.

#LIBWSVP2[P]:/tmp # hares -display mount17 -attribute ArgListValues -type Mount -sys `hostname` |grep -v ^#
#mount17      ArgListValues      LIBWSVP2   MountPoint   1       /sapmnt/LSP     BlockDevice     1       /dev/vx/dsk/sabw02/fsapmntLSP
# FSType  1       vxfs    MountOpt        1       ""      FsckOpt 1       -y      SnapUmount      1       0       CkptUmount      1
#  1       SecondLevelMonitor      1       0       SecondLevelTimeout      1       30

#LIBQASVT1[T]:/ISC/shell # hares -display -attribute ArgListValues -type Mount -sys `hostname` | grep -v ^#
#mnt_dbdl         ArgListValues           LIBQASVT1  /dbdl /dev/vx/dsk/qasvt1_dg02/v_dbdl vxfs "" -y 0


function get_local_mount_options {
  if [ $# -eq 9 ]; then
    MOUNT_POINT=$4
    BLOCK_DEVICE=$5
    FILESYSTEM_TYPE=$6
    return
  fi
  if [ $# -gt 3 ]; then
   shift;shift;shift
  fi
  while [ $# -gt 0 ]; do
    OPTION=$1
    case $OPTION in
      MountPoint)
        shift
        shift
        MOUNT_POINT=$1
        ;;
      BlockDevice)
        shift
        shift
        BLOCK_DEVICE=$1
        ;;
      FSType)
        shift
        shift
        FILESYSTEM_TYPE=$1
        ;;
      *)
        shift
        ;;
    esac
  done
}



hares -display -type Mount > /dev/null
LOCAL_MOUNT_POINT_EXIST=$?
############################################################################
# if local mount point exists
############################################################################
if [ $LOCAL_MOUNT_POINT_EXIST -eq 0 ]; then
  hares -display -attribute ArgListValues -type Mount -sys `hostname` | grep -v ^# | while read LINE
  do
    
    get_local_mount_options $LINE
    printf "mount -V %s %s %s\n" $FILESYSTEM_TYPE $BLOCK_DEVICE $MOUNT_POINT >> $OUTFILE
  done
fi

[[ -f $OUTFILE ]] && cp -p $OUTFILE $OUTFILE.$DATE
[[ -f $OUTFILE ]] && cp -p $OUTFILE $OUTFILE.$DATE
