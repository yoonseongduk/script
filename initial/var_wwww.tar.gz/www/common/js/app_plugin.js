jQuery(function($){
	$.datepicker.regional['ko'] = {
		closeText: '닫기',
		prevText: '이전달',
		nextText: '다음달',
		currentText: '오늘',
		monthNames: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
		monthNamesShort: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
		dayNames: ['일','월','화','수','목','금','토'],
		dayNamesShort: ['일','월','화','수','목','금','토'],
		dayNamesMin: ['일','월','화','수','목','금','토'],
		weekHeader: 'Wk',
		dateFormat: 'yy-mm-dd',
		firstDay: 0,
		isRTL: false,
		showMonthAfterYear: true,
		yearSuffix: '년'
	};
	$.datepicker.setDefaults($.datepicker.regional['ko']);
	$.datepicker.setDefaults({
		showOn: "button",
		buttonImage: '/images/button/btn_icon_calendar.gif',
		buttonImageOnly: true,
		showAnim: "slideDown",
		showOtherMonths: true,
		selectOtherMonths: true,
		changeMonth: true,
		changeYear: true,
		buttonText: ""
	});
	
	//browser detect
	$.browser = (function() {
		var ua = navigator.userAgent.toLowerCase();
        var match = /(chrome)[ \/]([\w.]+)/.exec( ua ) ||
        /(webkit)[ \/]([\w.]+)/.exec( ua ) ||
        /(opera)(?:.*version|)[ \/]([\w.]+)/.exec( ua ) ||
        /(msie) ([\w.]+)/.exec( ua ) ||
        ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec( ua ) ||
        [];
		return { name: match[1] || "", version: match[2] || "0" };
	}());
});


Globalize.culture('de-DE');
$.widget("ui.timespinner", $.ui.spinner, {
	options : {
		//step : 60 * 1000, // 1m
		step : 60 * 10 * 1000, // 10m
		page : 60
	},
	_parse : function(value) {
		if (typeof value === "string") {
			if (Number(value) == value) {
				return Number(value);
			}
			return +Globalize.parseDate(value);
		}
		return value;
	},
	_format : function(value) {
		return Globalize.format(new Date(value), "T");
	}
});

HashMap = function() {
	this.map = new Array();
};
HashMap.prototype = {
	put : function(key, value) {
		this.map[key] = value;
	},
	get : function(key) {
		return this.map[key];
	},
	getAll : function() {
		return this.map;
	},
	clear : function() {
		this.map = new Array();
	},
	getKeys : function() {
		var keys = new Array();
		for (i in this.map) {
			keys.push(i);
		}
		return keys;
	},
	remove: function(key) {
		//this.map.splice(key, 1);
		delete this.map[key];
	},
	size: function() {
		var cnt = 0;
		for (var key in this.map) {
			cnt++;
		}
		return cnt;		
	}
};