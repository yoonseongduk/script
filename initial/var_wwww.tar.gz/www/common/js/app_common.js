// =============================================================================================
// 숫자 쉼표 제거
// =============================================================================================
function GetNumParseComma(str) {
	var rtn = parseFloat(str.replace(/,/gi, ""));
	if (isNaN(rtn)) {
		return 0;
	}
	else {
		return rtn;
	}
}

// =============================================================================================
// 숫자 쉼표 추가
// =============================================================================================
function GetNumAddComma(str) {
	var reg = /(^[+-]?\d+)(\d{3})/;
	str += '';
	while (reg.test(str)) str = str.replace(reg, '$1' + ',' + '$2');
	return str;   
}

// =============================================================================================
// LPad
// =============================================================================================
function LPad(str, padLength, padChar) {
	var paddStr = str.toString();
	for (var i = str.length + 1; i <= padLength; i++) {
		paddStr = padChar + paddStr;
	}
	return paddStr;
}

function getToday () {
	var nowDate = new Date();
	var nowYear = nowDate.getFullYear();
	var nowMonth = nowDate.getMonth() + 1;
	var nowDay = nowDate.getDate();

	if (nowMonth < 10) {
		nowMonth = "0" + nowMonth;
	}
	if (nowDay < 10) {
		nowDay = "0" + nowDay;
	}
	return nowYear + "-" + nowMonth + "-" + nowDay;
}


// =============================================================================================
// 키워드 마크설정
// =============================================================================================
function markKeySrch (contents, key) {
	if (contents == null || contents == "") return "";
	if (key) {
		contents = contents.replace (key, "<span style='background-color: #E5CCA8;'>" + key + "</span>");
	}
	return contents;
}

// ==================================================================================================
// 로그명 설정
// ==================================================================================================
function setLogName (objID, log_date, defValue) {
	//
	var tagObject = $("#tag_name");
	if (tagObject) {
		tagObject.html ("");
		tagObject.append("<option value=''>::선택::</option>");
	}
	//
	if (!log_date) return;
	var divObject = $("#" + objID);
	$.ajax({
		type: "POST",
		cache: false,
		async: false,
		data: "log_date=" + log_date,
		url: "/rest/chart/get_logname_bydate.do",
		dataType: "json",
		success: function(data) {
			divObject.html ("");
			divObject.append("<option value=''>::선택::</option>");
			for (var i=0;i<data.rows.length;i++) {
				var mLogNm = data.rows[i];
				if (defValue && mLogNm == defValue) {
					divObject.append("<option value='" + mLogNm + "' selected='selected'>" + mLogNm +"</option>");
				} else {
					divObject.append("<option value='" + mLogNm + "'>" + mLogNm +"</option>");
				}
			}
			// 로그명이 n개일 경우, 첫번째 로그를 디폴트로 선택해줌. + 선택된 로그 TAG정보 Set
			if (data.rows.length > 0 && !defValue) {
				$("#" + objID + " option:eq(1)").attr("selected", "selected");
				$("#" + objID).trigger('change');
			} else if (data.rows.length > 0 && defValue) {
				$("#" + objID).trigger('change');
			}
		},
		error: function(request, status, error) {
			alert("처리중 오류가 발생하였습니다. > " + request.responseText);
		}
	});		
}

// ==================================================================================================
// TAG 설정
// ==================================================================================================
function setTagName (objID, mLogNm, mLogDt, defValue, mID) {
	var divObject = $("#" + objID);
	divObject.html ("");
	divObject.append("<option value=''>::선택::</option>");	
	if (mLogNm == "") {
		return;
	}
	
	$.ajax({
		type: "POST",
		cache: false,
		data: "log_date=" + mLogDt + "&log_name=" + mLogNm,
		url: "/rest/chart/get_tag_bylognm.do",
		dataType: "json",
		success: function(data) {
			for (var i=0;i<data.rows.length;i++) {
				var mLogObj = data.rows[i];
				if (defValue && mLogObj == defValue) {
					divObject.append("<option value='" + mLogObj + "' selected='selected'>" + mLogObj +"</option>");
				} else {
					divObject.append("<option value='" + mLogObj + "'>" + mLogObj +"</option>");
				}
			}
			if (data.rows.length > 0) {
				if (mLogNm && defValue) {
					$("#btn_chart_" + mID).click ();
				}
				/*
				if (!defValue) {
					$("#" + objID + " option:eq(1)").attr("selected", "selected");
				}
				*/				
			}
		},
		error: function(request, status, error) {
			alert("처리중 오류가 발생하였습니다. > " + request.responseText);
		}
	});		
}

function replaceRuleComp(tagComp) {
	switch (tagComp) {
		case "lt":
			return "<";
		case "eqlt":
			return "<=";	
		case "gt":
			return ">";
		case "eqgt":
			return ">=";
		default:
			return "==";
	}
}

// ==================================================================================================
// Random Color
// ==================================================================================================
function getRandomColor() {
    var letters = '0123456789ABCDEF'.split('');
    var color = '#';
    for (var i = 0; i < 6; i++ ) {
        color += letters[Math.round(Math.random() * 15)];
    }
    return color;
}

function setRandomColor (objId) {
	var rColor = getRandomColor ();
	$("#" + objId + " div").css("backgroundColor", rColor);
	$("#" + objId).ColorPickerSetColor (rColor);
}

function exceptionMsg(id, msg) {
	//alert("[" + id + "] " + msg);
}

function showLoading () {
	$(".layer-loading").fadeIn(500);
}

function hideLoading () {
	$(".layer-loading").hide();
}

