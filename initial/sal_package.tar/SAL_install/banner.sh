#!/usr/bin/ksh
################################################################################
#
# Script Name: bannel.sh
#
# Description: banner script for lunux server
#
# Modified:
#
#  2010.08.15 SAL_SUM:01816
#             created by root
#
# Licensed Materials - Property of LG CNS
#
# (C) COPYRIGHT LG CNS Co., Ltd. 2009
# All Rights Reserved
#
################################################################################

. $GCOMLIB/salc_global.func
set  -A array "$@"
typeset arr_cnt=$#

typeset      in_str=""
typeset      in_len=0
typeset      i=0

typeset BIG_CH_LEN=10     ## screen display charactor 
typeset dq='"'
typeset max_byte=7
typeset cur_pos=0         ## current position

typeset max_char=10       ## column: input charactor 
typeset max_line=7        ## raw
set -A  BUF_POOL "dummy"  ## array   9(15 Byte) * 14 ##
                          ## display 9(16 Byte) * 15 ##

typeset clear_char=" "
typeset buf_line=""
typeset -L${max_byte} buf_unit

[[ $BIG_CH_LEN -lt 1         ]] && BIG_CH_LEN=1
[[ $BIG_CH_LEN -gt $max_char ]] && BIG_CH_LEN=$max_char


tbl[0]="00000000000000" #  0
tbl[1]="00000000000000" #  1
tbl[2]="00000000000000" #  2
tbl[3]="00000000000000" #  3
tbl[4]="00000000000000" #  4
tbl[5]="00000000000000" #  5
tbl[6]="00000000000000" #  6
tbl[7]="00000000000000" #  7
tbl[8]="00000000000000" #  8
tbl[9]="00000000000000" #  9
tbl[10]="00000000000000" # 10
tbl[11]="00000000000000" # 11
tbl[12]="00000000000000" # 12
tbl[13]="00000000000000" # 13
tbl[14]="00000000000000" # 14
tbl[15]="00000000000000" # 15
tbl[16]="00000000000000" # 16
tbl[17]="00000000000000" # 17
tbl[18]="00000000000000" # 18
tbl[19]="00000000000000" # 19
tbl[20]="00000000000000" # 20
tbl[21]="00000000000000" # 21
tbl[22]="00000000000000" # 22
tbl[23]="00000000000000" # 23
tbl[24]="00000000000000" # 24
tbl[25]="00000000000000" # 25
tbl[26]="00000000000000" # 26
tbl[27]="00000000000000" # 27
tbl[28]="00000000000000" # 28
tbl[29]="00000000000000" # 29
tbl[30]="00000000000000" # 30
tbl[31]="00000000000000" # 31
tbl[32]="00000000000000" # 32
tbl[33]="1C1C1C08001C1C" # 33
tbl[34]="77772200000000" # 34
tbl[35]="14147F147F1414" # 35
tbl[36]="3E49483E09493E" # 36
tbl[37]="71527408172547" # 37
tbl[38]="18241838454239" # 38
tbl[39]="1C1C0810000000" # 39
tbl[40]="0C10202020100C" # 40
tbl[41]="18040202020418" # 41
tbl[42]="0022147F142200" # 42
tbl[43]="0008083E080800" # 43
tbl[44]="0000001C1C0810" # 44
tbl[45]="0000003E000000" # 45
tbl[46]="000000001C1C1C" # 46
tbl[47]="01020408102040" # 47
tbl[48]="1C22414141221C" # 48
tbl[49]="0818280808083E" # 49
tbl[50]="3E41013E40407F" # 50
tbl[51]="3E41013E01413E" # 51
tbl[52]="404242427F0202" # 52
tbl[53]="7F40407E01413E" # 53
tbl[54]="3E41407E41413E" # 54
tbl[55]="7F420408101010" # 55
tbl[56]="3E41413E41413E" # 56
tbl[57]="3E41413F01413E" # 57
tbl[58]="081C0800081C08" # 58
tbl[59]="1C1C001C1C0810" # 59
tbl[60]="04081020100804" # 60
tbl[61]="00003E003E0000" # 61
tbl[62]="10080402040810" # 62
tbl[63]="3E41010E080008" # 63
tbl[64]="3E415D5D5E403E" # 64
tbl[65]="081422417F4141" # 65
tbl[66]="7E41417E41417E" # 66
tbl[67]="3E41404040413E" # 67
tbl[68]="7E41414141417E" # 68
tbl[69]="7F40407C40407F" # 69
tbl[70]="7F40407C404040" # 70
tbl[71]="3E41404F41413E" # 71
tbl[72]="4141417F414141" # 72
tbl[73]="1C08080808081C" # 73
tbl[74]="0101010141413E" # 74
tbl[75]="42444870484442" # 75
tbl[76]="4040404040407F" # 76
tbl[77]="41635549414141" # 77
tbl[78]="41615149454341" # 78
tbl[79]="7F41414141417F" # 79
tbl[80]="7E41417E404040" # 80
tbl[81]="3E41414145423D" # 81
tbl[82]="7E41417E444241" # 82
tbl[83]="3E41403E01413E" # 83
tbl[84]="7F080808080808" # 84
tbl[85]="4141414141413E" # 85
tbl[86]="41414141221408" # 86
tbl[87]="41494949494936" # 87
tbl[88]="41221408142241" # 88
tbl[89]="41221408080808" # 89
tbl[90]="7F02040810207F" # 90
tbl[91]="3E20202020203E" # 91
tbl[92]="40201008040201" # 92
tbl[93]="3E02020202023E" # 93
tbl[94]="08142200000000" # 94
tbl[95]="0000000000007F" # 95
tbl[96]="1C1C0804000000" # 96
tbl[97]="000C12213F2121" # 97
tbl[98]="003E213E21213E" # 98
tbl[99]="001E212020211E" # 99
tbl[100]="003E212121213E" #100
tbl[101]="003F203E20203F" #101
tbl[102]="003F203E202020" #102
tbl[103]="001E212027211E" #103
tbl[104]="0021213F212121" #104
tbl[105]="00040404040404" #105
tbl[106]="0001010101211E" #106
tbl[107]="0021223C242221" #107
tbl[108]="0020202020203F" #108
tbl[109]="0021332D212121" #109
tbl[110]="00213129252321" #110
tbl[111]="001E212121211E" #111
tbl[112]="003E21213E2020" #112
tbl[113]="001E212125221D" #113
tbl[114]="003E21213E2221" #114
tbl[115]="001E201E01211E" #115
tbl[116]="001F0404040404" #116
tbl[117]="0021212121211E" #117
tbl[118]="0021212121120C" #118
tbl[119]="002121212D3321" #119
tbl[120]="0021120C0C1221" #120
tbl[121]="00110A04040404" #121
tbl[122]="003F020408103F" #122
tbl[123]="1C20206020201C" #123
tbl[124]="08080800080808" #124
tbl[125]="1C02020302021C" #125
tbl[126]="30490600000000" #126
tbl[127]="00000000000000" #127


function BUF_CLEAR {
  ## quick return start ##
  #cur_pos=0; return 
  ## quick return end ##


  typeset i=0  ## colume position  max_char
  typeset j=0  ## raw    position  max_line
  typeset x=""

  i=0; x=""
  while [[ $i -lt $max_byte ]] ; do
        (( i = $i + 1 )); x="$x$clear_char"  
  done
  buf_unit="$x"

  i=0
  while [[ $i -lt $max_char ]] ; do
        (( i = $i + 1 ))

        j=0
        while [[ $j -lt $max_line ]] ; do
              (( j = $j + 1 ))

              (( k = $i * $max_line + $j ))
              BUF_POOL[$k]=$buf_unit
        done
  done
  cur_pos=0  ## buffer clear ##
}

function BUF_PRINT_POS {
  typeset pos=${1:-30}
  typeset i=0
  typeset j=0

  [[ $pos -gt $max_char ]] && pos=$max_char

  j=0
  while [[ $j -lt $max_line ]] ; do
        (( j = $j + 1 ))

        i=0; buf_line=""
        while [[ $i -lt $pos ]] ; do
              (( i = $i + 1 ))

              (( k = $i * $max_line + $j ))
              buf_line="$buf_line${BUF_POOL[$k]} "
        done
        echo "$buf_line"
   done
   echo ""

   BUF_CLEAR
   cur_pos=0
}

function next_pos {
   (( cur_pos = $cur_pos + 1 )) ;
   ## echo "$pos"
   if [[ $cur_pos  -gt $BIG_CH_LEN ]] ; then
      BUF_PRINT_POS $BIG_CH_LEN
      cur_pos=1
   fi
}

function mini_banner_BUF_ADD {
  typeset A=$1
  typeset len=${#A}
  typeset i=0
  typeset j=0
  typeset -R7 y
  typeset strbk=""
          
  next_pos
  while [[ $i -lt $len ]] ; do
     substr $A $i 2 STR ; [[ "$strbk" != "$STR" ]] && x2b $STR xx 
     y=$xx ## re_arrange ##
     (( j = $j + 1 ))
     (( k = $cur_pos * $max_line + $j ))
     BUF_POOL[$k]=$y
     (( i = $i + 2 )); strbk=$STR
  done

}

function mini_banner {
  typeset A=$1
  typeset len=${#A}
  typeset i=0
  typeset -R7 y
  while [[ $i -lt $len ]] ; do
     substr $A $i 2 STR ; x2b $STR y
     echo "$y"

     (( i = $i + 2 ))
  done
}


## main routine ##
function main { 
 typeset i=0

 BUF_CLEAR

 i=0 
 while [[ $i -lt $in_len ]] ; do
      substr "$in_str" $i 1 y
      idy=" "; c2x "$y" idy; idx=" "; x2d "$idy" idx 
      x=${tbl[$idx]}
 
      ## if space then skip ##
      if [[ "$idy" != "20" ]] ; then  
         mini_banner_BUF_ADD $x 
      else
         next_pos   ## skip processing ## 
      fi
      (( i = $i + 1 )) 
 done
 [[ $cur_pos -gt 0 ]] && BUF_PRINT_POS $cur_pos
}


i=0
while [[ $i -lt $arr_cnt ]] ; do
   
   in_str=${array[$i]}
   in_len=${#in_str}
   
           main      | tr '[01]' '[ #]' 

   (( i = $i + 1 ))
done

return 0
# SAL_SUM:01816:2010.08.15 Do not delete this line
