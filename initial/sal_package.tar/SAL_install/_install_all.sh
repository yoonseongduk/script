#!/usr/bin/ksh
################################################################################
#
# Script Name: _install_all.sh
#
# Description: sal_package install script                                    
#
# Modified
#
#  2011.12.04 SAL_SUM:50760
#             add gems_search,dca_search
#  2010.12.01 SAL_SUM:29434
#             add dateform,unix2week
#  2010.10.10 SAL_SUM:33855
#             add bms_conv
#  2010.09.28 SAL_SUM:47131 ## 20100928 ##
#             add history_box, sal_help
#  2010.08.15 SAL_SUM:09984 ## 20100815 ##
#             add cdx,mvx,iplinfo,cprs,dategap,root_gdc_drop.sh ... etc
#  2009.11.03 SAL_SUM:21928
#             add sum.rexx       ## 20091103 ##
#  2009.09.23 SAL_SUM:01513
#             add temp dir clear ## 20090923 ##
#  2009.09.21 SAL_SUM:08895
#             add gadmin  
#  2009.09.17 SAL_SUM:21630
#             add datecomp
#  2009.09.08 SAL_SUM:25696
#             add df.rexx,skel.local
#  2009.09.02 SAL_SUM:07043
#             add copy_service unix_to_dos dos_to_unix
#  2009.08.25 SAL_SUM:36044
#             add skel
#  2009.08.06 SAL_SUM:45391
#             add cpbk2              
#  2009.05.15 SAL_SUM:18925
#             add ssum symbolic link 
#  2009.04.28 SAL_SUM:37284
#             add root profile check (add PATH) 
#  2009.04.01 SAL_SUM:01646
#             add $perm        
#  2009.03.31 SAL_SUM:46817
#             create by sdyoon
#
# Licensed Materials - Property of LG CNS
#
# (C) COPYRIGHT LG CNS Co., Ltd. 2009
# All Rights Reserved
#
################################################################################

  perm=$1; prof=$2

  if [[ "$GDC" = "" ]] ; then
     echo " GDC not set... install failed...!!! "
     exit
  fi

  export GCOMLIB=/${GDC}/sorc001/root/shell/SAL

  logdir=/${GDC}/logs001/root/shell/SAL
  logfile=sal_package.$(date +%Y%m%d).$(date +%H%M%S)
  logdf=$logdir/$logfile
  mkdir -p /usr/local/bin
  mkdir -p $logdir
  mkdir -p /${GDC}/logs001/BACKUP
  mkdir -p /${GDC}/logs001/DAILY  

  function sub_rtn {
     if [[ -d ./$1 ]] ; then                      ## 20090923 ##
        [[ "$1" = "gadmin" ]]  && rm -r ./gadmin  ## 20090923 ##
     fi                                           ## 20090923 ##

     tar -xvf $1.tar  ; cd $1;  ./_install.sh ; cd -
  }

  function copy_rtn {
     cp -p K10iplinfo       /usr/local/bin/       ## 20100815 ##
     cp -p S10iplinfo       /usr/local/bin/       ## 20100815 ##

     cp -p banner.sh        /usr/local/bin/       ## 20100815 ##
     ## if banner not found then ##               ## 20100815 ##
     which banner > /dev/null 2>&1                ## 20100815 ## 
     [[ $? -ne 0 ]] && {  
        [[ -f /usr/local/bin/banner ]] && rm /usr/local/bin/banner
        ln -s /usr/local/bin/banner.sh /usr/local/bin/banner 
     }
     cp -p cdx              /usr/local/bin/       ## 20100815 ##
     [[ -f /usr/local/bin/cdx.local ]] || cp -p cdx.local /usr/local/bin/

     cp -p copy_service     /usr/local/bin/     
     [[ -f /usr/local/bin/copy_apache ]] && rm /usr/local/bin/copy_apache
     [[ -f /usr/local/bin/copy_oracle ]] && rm /usr/local/bin/copy_oracle
     [[ -f /usr/local/bin/copy_group  ]] && rm /usr/local/bin/copy_group 
     [[ -f /usr/local/bin/copy_websp  ]] && rm /usr/local/bin/copy_websp 
     [[ -f /usr/local/bin/copy_abc    ]] && rm /usr/local/bin/copy_abc   
     [[ -f /usr/local/bin/copy_fs     ]] && rm /usr/local/bin/copy_fs    
     ln -s /usr/local/bin/copy_service  /usr/local/bin/copy_apache
     ln -s /usr/local/bin/copy_service  /usr/local/bin/copy_oracle
     ln -s /usr/local/bin/copy_service  /usr/local/bin/copy_group
     ln -s /usr/local/bin/copy_service  /usr/local/bin/copy_websp
     ln -s /usr/local/bin/copy_service  /usr/local/bin/copy_abc
     ln -s /usr/local/bin/copy_service  /usr/local/bin/copy_fs 

     cp -p cpbk             /usr/local/bin/
     cp -p cpbk2            /usr/local/bin/
     cp -p cprs             /usr/local/bin/       ## 20100815 ##
     cp -p bms_conv         /usr/local/bin/
     cp -p date2unix        /usr/local/bin/
     cp -p datecomp         /usr/local/bin/     
     cp -p dateform         /usr/local/bin/       ## 20101201 ##
     cp -p dategap          /usr/local/bin/       ## 20100815 ##
     cp -p dos_to_unix      /usr/local/bin/     
     cp -p gdc_check        /usr/local/bin/
     cp -p gems_search      /usr/local/bin/       ## 20111204 ##
     cp -p dca_search       /usr/local/bin/       ## 20111204 ##
     cp -p history_box      /usr/local/bin/       ## 20100928 ##
     cp -p iplinfo          /usr/local/bin/       ## 20100815 ##
     cp -p mvx              /usr/local/bin/       ## 20100815 ##
     cp -p root_gdc_drop.sh /usr/local/bin/       ## 20100815 ##
     cp -p root_profile     /usr/local/bin/     

     cp -p sal_check_sum    /usr/local/bin/
     [[ -f /usr/local/bin/ssum        ]] && rm /usr/local/bin/ssum
     ln -s /usr/local/bin/sal_check_sum /usr/local/bin/ssum

     cp -p sal_help         /usr/local/bin/       ## 20100928 ##
     cp -p ssum_all_check   /usr/local/bin/

     cp -p skel             /usr/local/bin/
     [[ -f /usr/local/bin/sal.local ]] || cp -p skel.local /usr/local/bin/

     cp -p unix2date        /usr/local/bin/
     cp -p unix2week        /usr/local/bin/       ## 20101201 ##
     cp -p unix_to_dos      /usr/local/bin/     

     cp -p df.rexx          /usr/local/bin/     
     cp -p sum.rexx         /usr/local/bin/     
     cp -p timeconv.rexx    /usr/local/bin/     

  }

  ## main routine ##
  sub_rtn global  2>&1 | tee -a $logdf; read a?"Continue..... any key enter"
  sub_rtn modsctl 2>&1 | tee -a $logdf; read a?"Continue..... any key enter"
  sub_rtn logsctl 2>&1 | tee -a $logdf; read a?"Continue..... any key enter"
  sub_rtn bkupctl 2>&1 | tee -a $logdf; read a?"Continue..... any key enter"
  sub_rtn gadmin  2>&1 | tee -a $logdf; read a?"Continue..... any key enter"
  sub_rtn menuctl 2>&1 | tee -a $logdf; read a?"Continue..... any key enter"

  cd $GCOMLIB
  ./license.sh install $perm 2>&1 | tee -a $logdf
  cd -

  [[ -d /usr/local/bin ]] && copy_rtn

  rm K10iplinfo
  rm S10iplinfo
  rm banner.sh
  rm cdx
  rm cdx.local
  rm copy_service
  rm cpbk
  rm cpbk2
  rm cprs
  rm bms_conv
  rm date2unix
  rm datecomp
  rm dateform
  rm dategap
  rm dos_to_unix
  rm gdc_check
  rm gems_search
  rm dca_search
  rm history_box
  rm iplinfo
  rm mvx
  rm root_gdc_drop.sh
  rm root_profile
  rm sal_check_sum
  rm sal_help
  rm skel
  rm skel.local
  rm ssum
  rm ssum_all_check
  rm unix2date
  rm unix2week
  rm unix_to_dos

  rm df.rexx
  rm sum.rexx
  rm timeconv.rexx

  rm -r global
  rm -r modsctl
  rm -r logsctl
  rm -r bkupctl
  rm -r menuctl
  rm -r gadmin 

  rm _install.conf
  rm _install_all.sh
  rm _install_silence.sh
 
  [[ "$prof" = "profile" ]] && /usr/local/bin/root_profile

# SAL_SUM:50760:2011.12.06 Do not delete this line
