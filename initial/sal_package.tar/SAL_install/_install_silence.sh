#!/usr/bin/ksh
################################################################################
#
# Script Name: _install_silence.sh
#
# Description: silence install 
#
# Modified
#
#  2009.05.15 SAL_SUM:08564
#             add /etc/gdc.profile
#  2009.05.15 SAL_SUM:44010
#             create by sdy
#
# Licensed Materials - Property of LG CNS
#
# (C) COPYRIGHT LG CNS Co., Ltd. 2009
# All Rights Reserved
#
################################################################################

  export GDC=$1

  # sal global environment variable setting ....start
  if [[ -f /etc/gdc.profile ]] ; then

     NEW_GDC=$GDC
     . /etc/gdc.profile

     if [[ "$NEW_GDC" = "$GDC" ]] ; then
        : # OK
     else
        echo " NEW_GDC and Current_GDC was not matched !!! "
        echo " NEW_GDC=$NEW_GDC and Current_GDC=$GDC       "
        echo " Install failed ............................ "
        echo " Install failed ............................ "
        echo " Install failed ............................ "
        exit 1
     fi

  else
     echo "### notes: Do not delete this file      ####"   > /etc/gdc.profile
     echo "### /etc/gdc.profile is used to set GDC code"  >> /etc/gdc.profile
     echo "### ===created: $(date '+%Y%m%d %H:%M:%S') ===== ####"  >> /etc/gdc.profile
     echo "GDC=$GDC"                                      >> /etc/gdc.profile
  fi
  # sal global environment variable setting ....end


  cat ./_install.conf | ./_install_all.sh $2 $3  



# SAL_SUM:08564:2009.05.15 Do not delete this line
