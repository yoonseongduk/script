#!/usr/bin/ksh 
################################################################################
#
# Script Name: root_gdc_drop.sh
#
# Description: root profile check and GDC code drop script
#
# Modified:
#
#  2010.08.13 SAL_SUM:18505 ## 20100813 ##
#             created by root
#
# Licensed Materials - Property of LG CNS
#
# (C) COPYRIGHT LG CNS Co., Ltd. 2009
# All Rights Reserved
#
################################################################################
  
   [[ "$debug" = "yes" ]] && set -vx


   typeset profile="$HOME/.profile"
   typeset profile2="$HOME/.bash_profile"
   typeset cnt=0

   shell=$( echo $SHELL  | awk -F/ '{ print $NF }' )                      ## 20100813 ##
   { [[ "$shell" = "bash" ]] && [[ -f $profile2 ]] } && profile=$profile2 ## 20100813 ##

   cat $profile | egrep " GDC=|^GDC=|GDC$" | grep -v ^#
   cnt=$( cat $profile | egrep " GDC=|^GDC=|GDC$" | grep -v ^# | wc -l )

   if [[ $cnt -gt 0 ]] ; then
     TEMP="/tmp/temp.$$"
     cat $profile | awk '{
       al = ""; bk = " ";
       for (i = 1; i <= NF; i++) {
           if ( al == "" ) 
              al = $i
           else
              al = al bk $i
       }
       if ( index(al," GDC=") > 0 || index(al," GDC ") > 0 || index($1,"GDC=") == 1 || $NF == "GDC" ) {
             if ( index($1,"#") == 1 )
                a  = 'null'
             else
                al = "#"al
       }
       print al
     }' > $TEMP

     ## if awk process is ok then root_profile replace ## 
     [[ $? -eq 0 ]] && {
        /usr/local/bin/cpbk $profile  ## profile backup ##
        cp  $TEMP $profile
     }
     [[ -f $TEMP ]] && rm $TEMP
   fi
 
   return 0
# SAL_SUM:18505:2010.08.16 Do not delete this line
